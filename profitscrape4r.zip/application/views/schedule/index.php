<!DOCTYPE html>
<!--[if lt IE 7]>      
<html class="no-js lt-ie9 lt-ie8 lt-ie7">
<![endif]-->
<!--[if IE 7]>         
<html class="no-js lt-ie9 lt-ie8">
<![endif]-->
<!--[if IE 8]>         
<html class="no-js lt-ie9">
<![endif]-->
<!--[if gt IE 8]><!--> 
<html class="no-js">
  <!--<![endif]-->
  <head>
     <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
     <meta charset="UTF-8">
     <title>Ebay(USA) Product Details Scraper</title>
     <meta name="description" content="">
     <meta name="viewport" content="width=device-width">
<?php $this->load->view('includes/header')?>
  </head>
  <body>
     <!--[if lt IE 7]>
     <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
     <![endif]-->
     <?php
        if ($_SESSION) {
          # code...
        }
        else{
        
          die();
        }
        ?>
     <div id="wrapper" class="active">
<?php $this->load->view('includes/menu-top')?>
    <!-- END NAVBAR -->
        <?php //$this->load->view('includes/sidebar')?>
        <!-- Page content -->
        <div class="content -dark -with-left-sidebar -collapsible">
           <!-- Navigation & Logo-->
           <div class="container-fluid">
                <div class="row">
                    <div class="page-heading -dark">
                      <h1 style=" font-size: 30px;">Schedule List</h1>
                       </div>
                    </div>
                    
                </div>
           <!-- Homepage Slider -->
           <br>
           <div class="-dark -with-left-sidebar -collapsible " >
              <?php if ($this->session->flashdata('message')) { ?>
              <h4 class="alert alert-primary"><?php echo $this->session->flashdata('message'); ?></h4>
              <br>
              <?php } ?>
              <div class="col -xl-12">
                 <?php if($data){ ?>
                 <div class="page-heading -dark">
                    <!-- Widget -->
                    <div class="widget">
                       <!-- Widget heading -->
                       <div class="widget-head">
                          <h4 class="">Data Table</h4>
                       </div>
                       <!-- // Widget heading END -->
                       <div class="widget-body">
                          <!-- Table -->
                          <table class="table -dark -striped">
                             <!-- Table heading -->
                             <thead>
                                <tr>
                                   <th>Ebay Country</th>
                                   <!--<th>Product Link</th>-->
                                   <th>Ebay Seller ID</th>
                                   <th>Search Keyword</th>
                                   <th>Item Type</th>
                                   <th>Action</th>
                                </tr>
                             </thead>
                             <!-- // Table heading END -->
                             <!-- Table body -->
                             <tbody>
                                <?php
                                   if($data)
                                   {
                                     //print_r($data);
                                     $state=""; $seller_name="";
                                       foreach ($data as $row)
                                       {
                                         if($row->is_active==1)
                                           $state = "Deactive";
                                         if($row->is_active==2)
                                           $state = "Active";
                                         if($row->seller_name == "")
                                           $seller_name = "--";
                                         else
                                           $seller_name = $row->seller_name;
                                         if($row->keyword == "")
                                           $keyword = "--";
                                         else
                                           $keyword = $row->keyword;
                                   
                                         echo "<tr>
                                             <form>
                                             <td>".$row->search_from."</td>
                                             <td>".$seller_name."</td>
                                             
                                             <td>".$keyword."</td>
                                             <td>".$row->item."</td>
                                             
                                             <td class=''><a href=".base_url('index.php/Schedule/schedule_wise_pro/'.$row->user_sch_id)." class=' btn -light -xs' >View</a>
                                             
                                             <a href=\"#\" class='btn -danger -xs' onclick='delete_sch(".$row->user_sch_id.",this)'>Delete</a>
                                             </td>
                                             
                                             </form>
                                           </tr>"; 
                                           
                                           
                                       }
                                       echo "<div class='status alert alert-success' style='font-size:20px;display:none;'' '></div>";    
                                   }
                                   
                                   ?>
                             </tbody>
                             <!-- // Table body END -->
                          </table>
                          <!-- // Table END -->
                       </div>
                    </div>
                    <!-- // Widget END -->
                 </div>
                 <!-- // innerLR END -->

<!--                  <div class="pagination pagination-right margin-none">
                  <ul>
                    <li class="disabled"><a href="#">&laquo;</a></li>
                    <li class="active"><a href="#">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">&raquo;</a></li>
                  </ul>
                </div> -->
                 <?php } else echo "<span class='alert alert-default'> No Schedule Available!! </span>"; ?>
              </div>
           </div>
<!--            <div class="text-center">
              <ul class="pagination pagination-lg">
                 <?php if($data){ echo $links; }?>
              </ul>
           </div> -->
        </div>
     </div>
     <!-- Footer -->
     <?php $this->load->view('includes/footer')?>
  <script>

      function delete_sch(schedule_id,elm) {

        console.log(this);
          $.ajax({
             type: "POST",
             url: "<?php echo base_url()?>" + "Schedule/delete_schedule/",
             dataType: 'json',
             data:{sch_id:schedule_id},
             success: function(response){
             console.log("DELETED");
             console.log(this);
             $('.status').text("Row was deleted succesfuly").show();
             $('.status').fadeOut(2000);
             $(elm).parent().parent().hide();
             },
             error: function(error){
               console.log(error);
             } 
         });
      }

     // $('.delete_schedule').click(function(e){
     //   e.preventDefault();
     
     //   var current = $(this).parent().parent();
     //   var schedule_id = $(this).val();
     // console.log(current);
     // console.log(schedule_id);
     //   $.ajax({
     //       type: "POST",
     //       url: "<?php echo base_url()?>" + "Schedule/delete_schedule/",
     //       dataType: 'json',
     //       data:{sch_id:schedule_id},
     //       success: function(response){
     //       console.log("DELETED");
     //       console.log(this);
     //       $('.status').text("Row was deleted succesfuly").show();
     //       $('.status').fadeOut(2000);
     //       current.hide();
     //       },
     //       error: function(error){
     //         console.log(error);
     //       } 
     //   });
     
     // });
     
     // var sch_id = $('.delete_schedule').val();
     // var that = schedule_id;
     
     //   $.ajax({
     //       type: "POST",
     //       url: "<?php echo base_url()?>" + "index.php/Schedule/delete_schedule/" + that + "",
     //       dataType: 'json',
     //       success: function(response){
     //       console.log("DELETED");
     //       console.log(that);
     //       //$('input').val(that).parent().parent().hide();
     //       console.log($('input').val(that).parent());
     //       },
     //       error: function(response){
     //         console.log(response);
     //       } 
     //   });
     
     
     
     
     
     
     
     
     
     
     function loadDoc() {
     
     var xhttp = new XMLHttpRequest();
     var searchfrom=document.getElementById("searchfrom").value;
     var sellerid=document.getElementById("sellerid").value;
     var keyword=document.getElementById("keyword").value;
     var item=document.getElementById("item").value;
     sellerid=encodeURIComponent(sellerid);
     keyword=encodeURIComponent(keyword);
     item=encodeURIComponent(item);
     searchfrom=encodeURIComponent(searchfrom);
     
     xhttp.onreadystatechange = function() {
       if (this.readyState == 4 && this.status == 200) {
        //alert(this.responseText);
         $("#msg").html(this.responseText);
         $("#msg").attr("class", "alert alert-success");
         $("#ermsg").focus();
       }
     };
     $('#buttons').hide();
     //$('#display').show();
     xhttp.open("POST", "<?php echo base_url(); ?>index.php/ebay/execute_scraper", true);
     xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
     xhttp.send("sellerid="+sellerid+"&keyword="+keyword+"&item="+item+"&searchfrom="+searchfrom);
     setInterval(function(){location.reload();},5000);
     
     }
     
     function stopScript(){
     var xhttp = new XMLHttpRequest();
     xhttp.onreadystatechange = function() {
       if (this.readyState == 4 && this.status == 200) {
        //alert(this.responseText);
         $("#msg").html(this.responseText);
         $("#msg").attr("class", "alert alert-success");
         $("#ermsg").focus();
       }
     };
     
     xhttp.open("POST", "<?php echo base_url(); ?>index.php/ebay/stop_execution", true);
     xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
     xhttp.send();
     setInterval(function(){location.reload();},1000);
     }
     
     
  </script>
</html>
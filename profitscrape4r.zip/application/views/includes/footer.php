      <div class="footer">
        <div class="container">

          <div class="row">
            <div class="col-md-12 text-center">
              <div class="footer-copyright">DSB&copy; 2017.</div>
            </div>
          </div>
        </div>
      </div>

    <script src="<?php echo base_url('public/template/build/vendors/jquery/jquery.js')?>" type="text/javascript"></script>
    <script src="<?php echo base_url('public/template/build/vendors/gsap/gsap.js')?>" type="text/javascript"></script>
    <script src="<?php echo base_url('public/template/build/vendors/browser/browser.js')?>" type="text/javascript"></script>
    <script src="<?php echo base_url('public/template/build/vendors/hammer/hammer.js')?>" type="text/javascript"></script>
    <script src="<?php echo base_url('public/template/build/vendors/tether/tether.js')?>" type="text/javascript"></script>
    <script src="<?php echo base_url('public/template/build/vendors/moment/moment.js')?>" type="text/javascript"></script>
    <script src="<?php echo base_url('public/template/build/vendors/bootstrap/bootstrap.js')?>" type="text/javascript"></script>
    <script src="<?php echo base_url('public/template/build/vendors/bootstrap/plugins/modal.js')?>" type="text/javascript"></script>
    <script src="<?php echo base_url('public/template/build/vendors/datepicker/datepicker.js')?>" type="text/javascript"></script>
    <script src="<?php echo base_url('public/template/build/vendors/validator/validator.js')?>" type="text/javascript"></script>
    <script src="<?php echo base_url('public/template/build/vendors/perfect-scrollbar/perfect-scrollbar.js')?>" type="text/javascript"></script>
    <script src="<?php echo base_url('public/template/build/vendors/gritter/gritter.js')?>" type="text/javascript"></script>
    <script src="<?php echo base_url('public/template/build/vendors/metismenu/metismenu.js')?>" type="text/javascript"></script>
    <script src="<?php echo base_url('public/template/build/resources/js/themes/picker.js')?>" type="text/javascript"></script>
    <script src="<?php echo base_url('public/template/build/resources/js/animus/animus.js')?>" type="text/javascript"></script>
    <script src="<?php echo base_url('public/template/build/resources/js/components/morph-dropdown.js')?>" type="text/javascript"></script>
    <script src="<?php echo base_url('public/template/build/resources/js/components/navbar.js')?>" type="text/javascript"></script>
    <script src="<?php echo base_url('public/template/build/resources/js/components/panel.js')?>" type="text/javascript"></script>
    <script src="<?php echo base_url('public/template/build/resources/js/components/sidebar.js')?>" type="text/javascript"></script>
    <script src="<?php echo base_url('public/template/build/resources/js/dashboard/dashboard.js')?>" type="text/javascript"></script>
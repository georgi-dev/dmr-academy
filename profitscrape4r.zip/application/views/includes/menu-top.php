    <!-- Loading Spinner-->
    <div class="loader-wrapper">
      <div class="loader"><span class="loader-block"></span><span class="loader-block"></span><span class="loader-block"></span><span class="loader-block"></span><span class="loader-block"></span><span class="loader-block"></span><span class="loader-block"></span><span class="loader-block"></span><span class="loader-block"></span><span class="loader-block"></span><span class="loader-block"></span><span class="loader-block"></span><span class="loader-block"></span><span class="loader-block"></span><span class="loader-block"></span><span class="loader-block"></span>
      </div>
    </div>
    <!-- /Loading Spinner-->
<div class="navbar -dark -fixed-top -has-6-items">
      <div class="navbar-wrapper">
        <div class="sidebar-toggle hidden-lg-up hidden-xs-down" id="sidebar-toggle-navbar-brand" data-target="#sidebar"> <a href="javascript:void(0);"> <i class="fa fa-bars"> </i></a></div><a class="navbar-brand hidden-xs-down" href="<?php echo base_url('dashboard');?>"> 
          <h1>Profit Scalper</h1></a>
        <ul class="navbar-nav -right">
          <!-- <li class="sidebar-toggle hidden-sm-up" id="sidebar-toggle" data-target="#sidebar"> <a href="javascript:void(0);"> <i class="fa fa-bars"> </i></a></li> -->
          <!-- <li> <a class="has-morph-dropdown" href="#notifications-dropdown"><i class="pe pe-bell"></i><span class="navbar-item-count">2</span></a></li> -->
          <!-- <li> <a class="has-morph-dropdown" href="#applications-dropdown"><i class="pe pe-keypad"></i></a></li> -->
          <li class="navbar-profile"> <a class="has-morph-dropdown" href="#profile-dropdown"><i class="pe pe-user"></i></a></li>
          <!-- <li class="sidebar-toggle" id="sidebar-secondary-toggle" data-target="#sidebar-secondary"> <a href="javascript:void(0);"> <i class="fa fa-ellipsis-v"> </i></a></li> -->
        </ul>
        <ul class="" style="list-style:none  ;  line-height: 4.5;">
          <li class="d-inline-block px-3">
            <a href="<?php echo base_url('Dashboard');?>"> <i class="pe pe-home"></i><span> Dashboard</span></a>
          </li>
          <li class="d-inline-block px-3">
            <a href="<?php echo base_url('schedule');?>"> <i class="fa fa-list"></i><span> Schedule List</span></a>
          </li>
          <li class="d-inline-block px-3">
            <a href="<?php echo base_url('schedule/add');?>"> <i class="fa fa-plus"></i><span> Add Schedule</span></a>
          </li>
        </ul>
        <div class="morph-dropdown-wrapper -dark -right">
          <div class="morph-dropdown-list -links">
            <!-- <div class="morph-dropdown" id="notifications-dropdown">
              <div class="morph-content">
                <h3>Notifications</h3>
                <p class="_text-muted">Here's what happened while you were away.</p>
                <ul class="morph-links -small">
                  <li><a href="#"> <img src="resources/img/users/male3.jpg"/> <strong>John Doe </strong> has accepted your team invitation.<small>Just Now</small></a></li>
                  <li><a href="#"><img src="resources/img/users/female1.jpg"/> <strong>Gabriella Cruz </strong> has invited you to her event.<small>12 Hours Ago</small></a></li>
                  <li><a href="#"><img src="resources/img/users/female2.jpg"/> <strong>Sofia Owens </strong> has started following you.<small>1 Day Ago</small></a></li>
                </ul>
                <div class="_margin-top-1x"> <a class="btn -primary -block">View All Notifications</a></div>
              </div>
            </div> -->
            <div class="morph-dropdown" id="applications-dropdown">
              <!-- <div class="morph-content -gallery">
                <h3>Applications</h3>
                <p class="_text-muted">Open one of your connected social applications.</p>
                <ul class="morph-gallery">
                  <li> <a href="https://facebook.com/pixevil" target="_blank"><i class="fa fa-facebook-square"> </i>Facebook</a></li>
                  <li> <a href="https://twitter.com/pixevil" target="_blank"><i class="fa fa-twitter"> </i>Twitter</a></li>
                  <li> <a href="https://plus.google.com/+pixevil" target="_blank"> <i class="fa fa-google-plus"> </i>Google Plus</a></li>
                  <li> <a href="https://linkedin.com/company/pixevil" target="_blank"><i class="fa fa-linkedin"> </i>LinkedIn</a></li>
                  <li> <a href="https://github.com/pixevil" target="_blank"><i class="fa fa-github"> </i>GitHub</a></li>
                  <li> <a href="https://bitbucket.org" target="_blank" rel="nofollow"><i class="fa fa-bitbucket"> </i>BitBucket</a></li>
                  <li> <a href="https://slack.com/" target="_blank" rel="nofollow"><i class="fa fa-slack"> </i>Slack</a></li>
                  <li> <a href="https://dropbox.com/" target="_blank" rel="nofollow"><i class="fa fa-dropbox"> </i>DropBox</a></li>
                </ul>
                <div class="_margin-top-1x"><a class="btn -primary -block">View All Applications</a></div>
              </div> -->
            </div>
            <div class="morph-dropdown" id="profile-dropdown">
              <div class="morph-content -links">
                <div class="morph-profile">
                  <h4><?php echo $this->session->username ;?></h4>
                  <p>Senior Web Developer </p>
                </div>
                <ul class="morph-links">
                  <li><a href="#">My Profile</a></li>
                  <li><a href="<?php echo base_url('profile/edit');?>">Account Edit</a></li>
                </ul>
                <div class="_margin-top-1x"> <a href="<?php echo base_url('index.php/auth/do_logout')?>"class="btn -primary -block">Sign Out</a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- END NAVBAR -->
<!-- Footer -->
      <div class="footer">
        <div class="container">
          
          <div class="row">
            <div class="col-md-12">
              <div class="footer-copyright">&copy; 2017.</div>
            </div>
          </div>
        </div>
      </div>

        <!-- Javascripts -->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="<? echo base_url('public/js/jquery-1.9.1.min.js'); ?>"><\/script>')</script>
        <script src=" <? echo base_url('public/js/bootstrap.min.js'); ?> "></script>
        <script src="http://cdn.leafletjs.com/leaflet-0.5.1/leaflet.js"></script>
        <script src=" <? echo base_url('public/js/jquery.fitvids.js'); ?>"></script>
        <script src=" <? echo base_url('public/js/jquery.sequence-min.js'); ?> "></script>
        <script src=" <? echo base_url('public/js/jquery.bxslider.js'); ?> "></script>
        <script src=" <? echo base_url('public/js/main-menu.js'); ?> "></script>
        <script src=" <? echo base_url('public/js/template.js'); ?> "></script>
        <script src=" <? echo base_url('public/js/sidebar.js'); ?> "></script>
        <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>

    </body>

    </html>
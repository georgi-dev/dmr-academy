<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Scraper extends CI_Controller {

	public function __construct()
	{
		parent:: __construct();
		$this->load->model("Scraper_model");
		$this->load->library('pagination');	
		$this->load->library('session');
		$this->load->library('form_validation');
		$this->load->helper('url');
	}

	public function scraper_ctrl()
	{
		$jobs = $this->Scraper_model->scraper_m();

		foreach ($jobs as $job) {
			
		    $this->Scraper_model->runScraper($job->id, $job->schedule_id);
		}
	}
}


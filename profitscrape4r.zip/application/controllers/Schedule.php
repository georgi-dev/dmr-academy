<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Schedule extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()

	{

		parent:: __construct();

		$this->load->database();

		$this->load->library('pagination');	

		$this->load->library('session');

		$this->load->library('form_validation');
		$this->load->helper('url');

		
	}
	
	public function index($pg=1)
	{
		$token = $this->session->userdata('token');

		if($token=="" || $token==null)
		{
			//redirect(base_url().'login', 'refresh');	
			header('location:'.base_url());
		}
		else
		{
			$this->load->model("Schedule_model");
			$this->load->model('User_schedule_model');
			$this->load->model('ebay_model');


			$token = $this->session->userdata('token');

			$user_id = $this->ebay_model->get_user_id($token);
			
			$id = $this->User_schedule_model->schedule_id($user_id['id']);

			$schedule_id = array();
			foreach ($id as $val) 
			{
				array_push($schedule_id,$val->schedule_id);
			}
			
			$recordcount = sizeof($schedule_id);
			$config["base_url"] = base_url()."index.php/schedule/index";
			$per_page=10;
			$config["total_rows"] = $recordcount;
			$config["per_page"] = $per_page;
			$config['use_page_numbers'] = TRUE;
			$config['num_links'] = $recordcount;
			$config['cur_tag_open'] = '&nbsp;<a class="current">';
			$config['cur_tag_close'] = '</a>';
			$config['next_link'] = 'Next';
			$config['prev_link'] = 'Previous';

			$this->pagination->initialize($config);
			if($this->uri->segment(3)){
				$page = ($this->uri->segment(3)) ;
			}
			else{
				$page = 1;
			}
			if($pg!=1)
				$pg=($pg-1)*10;
			else
				$pg=0;

			$pg=$page-1;
			$count=$per_page;
			$start=$count*$pg;
			$paginate="";
			$privious="";
			$next="";


			$records= $recordcount;
		    $i=$page-2;
		    if($i<=0)
		        $i=1;
		    $end=$records/$count;



		    for(; $i>0 && $i<$page ; $i++)
		    {
		        $privious="<li class='page-item'><a class='page-link' href='".base_url()."index.php/schedule/index/".$i."'>Previous</a></li>";

		        $paginate.="<li class='page-item'><a class='page-link' href='".base_url()."index.php/schedule/index/".$i."'>$i</a></li>";
		    }
		    if($page==0)
		        $page=1;
		    $paginate.="<li class='page-item active'><span class='page-link'>".$page."</span></li>";
		    $i=$i+1;


		    $isnext=0;
		    for(; $i<=$end && $i<$page+3 ; $i++)
		    {
		        if($isnext==0)
		        {
		            $next="<li class='page-item'><a class='page-link' href='".base_url()."index.php/schedule/index/".$i."'>Next</a></li>";
		            $isnext=1;
		        }
		        $paginate.="<li class='page-item'><a class='page-link' href='".base_url()."index.php/schedule/index/".$i."'>$i</a></li>";

		    }

		    if(($i-1)<$end)
		    {
		        $paginate.="<li class='page-item'><a class='page-link' href='".base_url()."index.php/schedule/index/".$i."'>".$i."</a></li>";
		        if($isnext==0)
		        {
		            $next="<li class='page-item'><a class='page-link' href='".base_url()."index.php/schedule/index/".$i."'>Next</a></li>";
		            $isnext=1;
		        }

		    }

			$data = $this->User_schedule_model->get_schedule($user_id['id'],$config["per_page"], $start);
			
			//$state = $this->User_schedule_model->get_state();
			//$links = $this->pagination->create_links();
			$links =$privious.$paginate.$next;

			$result = array('data'=>$data, 'links'=>$links);
			$this->load->view('schedule/index',$result);	
		}
		
	}


	public function add()
	{
		$token = $this->session->userdata('token');

		if($token=="" || $token==null)
		{
			//redirect(base_url().'login', 'refresh');	
			header('location:'.base_url());
		}
		else
		{
			if(isset($_POST['add']))
			{	
				$this->form_validation->set_rules('searchfrom', 'SearchFrom', 'required');
	            $this->form_validation->set_rules('item', 'Item', 'required');
	            //$this->form_validation->set_rules('sellerid', 'SellerId', 'required');
	            //$this->form_validation->set_rules('keyword', 'Keyword', 'required');
				
				if ($this->form_validation->run() == TRUE)
	            {

	            	$token = $this->session->userdata('token');

	            	$this->load->model("User_schedule_model");
	            	$this->load->model("Schedule_model");
	            	$this->load->model('ebay_model');
	            	$seller=$this->input->post('sellerid');
	            	$keyword=$this->input->post('keyword');
	            	if($seller=="" && $keyword=="")
	            	{
	            		$this->session->set_flashdata('message', 'Sellerid or keyword required!!');
	            	}
	            	else
	            	{
		            	$user_id = $this->ebay_model->get_user_id($token);
		            	
		            	$rec = array(
						'search_from' 	=> $this->input->post('searchfrom'),
						'seller_name' 	=> $this->input->post('sellerid'),
						'keyword' 		=> $this->input->post('keyword'),
						'item' 			=> $this->input->post('item'),
						'created_date' 	=> date('Y-m-d H:i:s'),
						//'updated_date' => date('Y-m-d H:i:s'),
						'updated_date' 	=> "",
						'user_id' 		=> $user_id['id'],
						'scraped_result'=> 0
						);

		            	$res = $this->Schedule_model->is_schedule_available($rec);

		            	if($res->num_rows() > 0)
		            	{
		            		$res = $res->row_array();
		            		$schedule_id = $res['schedule_id'];

		            		$rec = array(
							'user_id' => $user_id['id'],
							'schedule_id' => $schedule_id,
							'is_active' => 1
							);

							$res = $this->User_schedule_model->is_usr_sche_available($rec);
							if($res->num_rows() > 0)
							{
								$this->session->set_flashdata('message', 'Schedule already available!!');
								//$result = array('message' => 'Record Inserted Successfully');
								redirect('schedule/add');
							}
							else
							{
								$this->db->insert('user_schedule', $rec);

								$this->session->set_flashdata('message', 'New Schedule Added Successfully');
								//$result = array('message' => 'Record Inserted Successfully');
								redirect('schedule/index');
							}
							
		            	}
		            	else
		            	{
		            		$this->db->insert('scraper_schedule', $rec);
		            		$last_id = $this->db->insert_id();
		            		$rec = array(
							'user_id' 		=> $user_id['id'],
							'schedule_id' 	=> $last_id,
							'is_active' 	=> 1
							);
							$this->db->insert('user_schedule', $rec);

							$this->session->set_flashdata('message', 'Schedule Added Successfully');
							//$result = array('message' => 'Record Inserted Successfully');
							redirect('schedule/index');
		            	}

	            	}	

	            }
				
			}
			
			$this->load->view('schedule/add');
		}

	}



	public function change_state()
	{
		
		$this->load->model('User_schedule_model');
		//$this->User_schedule_model->change_state($_GET['id']);
		if($_GET['state']=='Active')
			$state = 1;
		if($_GET['state']=='Deactive')
			$state = 2;

		$usr_sche_id = $this->uri->segment(3);
		
		$data=array('is_active'=>$state);
		$this->db->where('user_sch_id', $usr_sche_id);
		$this->db->update('user_schedule',$data);
		
		redirect('schedule/index');
	}


	public function schedule_wise_pro($pg=1)
	{
		$token = $this->session->userdata('token');

		if($token=="" || $token==null)
		{
			//redirect(base_url().'login', 'refresh');	
			header('location:'.base_url());
		}
		else
		{
			
			//$usr_sche_id = $this->input->get('schid');
			$usr_sche_id = $this->uri->segment(3);


			$this->load->model('User_schedule_model');
			$this->load->model('ebay_model');
			$this->load->model("Schedule_model");
			$this->load->model("setting_model");
			$this->load->model("screen_message_model");

			$sche_id = $this->User_schedule_model->schedule_id2($usr_sche_id);
			
			
			$schedule_id = $sche_id[0]->schedule_id;

			$recordcount = $this->ebay_model->get_count($schedule_id);

			$state = $this->setting_model->get_state();
			$state = $state->result()[0]->state;

			$msginfo = array('seller'=>'', 'keyword'=>'', 'item'=>'', 'pageresult'=>'', 'search_link'=>'', 'searchfrom'=>'', 'scrapeditem'=>'');
			$msginfo['scrapeditem'] = $recordcount;

			//$scrmsg = $this->screen_message_model->get_message();
			$scrmsg = $this->screen_message_model->get_message($schedule_id);
			//print_r($scrmsg);
			$msginfo['seller'] = $scrmsg->result()[0]->seller_name;
			$msginfo['keyword'] = $scrmsg->result()[0]->keyword;
			$msginfo['item'] = $scrmsg->result()[0]->item;
			$msginfo['pageresult'] = $scrmsg->result()[0]->scraped_result;
			$msginfo['search_link'] = $scrmsg->result()[0]->search_link;
			$msginfo['searchfrom'] = $scrmsg->result()[0]->search_from;


			//$config["base_url"] = base_url()."index.php/Schedule/schedule_wise_pro";
			$config["base_url"] = base_url()."index.php/Schedule/schedule_wise_pro/".$usr_sche_id;
			//$config['first_url'] = $config['base_url'].'?'.http_build_query($_GET);

			$config["total_rows"] = $recordcount;
			$per_page=20;
			$config["total_rows"] = $recordcount;
			$config["per_page"] = $per_page;
			$config['use_page_numbers'] = TRUE;
			$config['num_links'] = $recordcount;
			$config['cur_tag_open'] = '&nbsp;<a class="current">';
			$config['cur_tag_close'] = '</a>';
			$config['next_link'] = 'Next';
			$config['prev_link'] = 'Previous';
			

			$this->pagination->initialize($config);
			if($this->uri->segment(4)){
				$page = ($this->uri->segment(4)) ;
			}
			else{
				$page = 1;
			}

			if($page!=1)
				$pg=($page-1)*20;
			else
				$pg=0;

			$pg=$page-1;
			$count=$per_page;
			$start=$count*$pg;
			$paginate="";
			$privious="";
			$next="";


			$records= $recordcount;
		    $i=$page-2;
		    if($i<=0)
		        $i=1;
		    $end=$records/$count;



		    for(; $i>0 && $i<$page ; $i++)
		    {
		        $privious="<li class='pagination-item'><a class='page-link' href='".base_url()."index.php/Schedule/schedule_wise_pro/$usr_sche_id/". $i ."'>Previous</a></li>";

		        $paginate.="<li class='-xs-[] pagination-item'><a class='page-link' href='".base_url()."index.php/Schedule/schedule_wise_pro/$usr_sche_id/". $i ."'>". $i ."</a></li>";
		    }
		    if($page==0)
		        $page=1;
		    $paginate.="<li class='pagination-item -active'><span class='page-link'>$page</span></li>";
		    $i=$i+1;


		    $isnext=0;
		    for(; $i<=$end && $i<$page+3 ; $i++)
		    {
		        if($isnext==0)
		        {
		            $next="<li class='pagination-item'><a class='page-link' href='".base_url()."index.php/Schedule/schedule_wise_pro/$usr_sche_id/". $i ."'>Next</a></li>";
		            $isnext=1;
		        }
		        $paginate.="<li class='pagination-item'><a class='page-link' href='".base_url()."index.php/Schedule/schedule_wise_pro/$usr_sche_id/". $i ."'>$i</a></li>";

		    }

		    if(($i-1)<$end)
		    {
		        $paginate.="<li class='pagination-item'><a class='page-link' href='".base_url()."index.php/Schedule/schedule_wise_pro/$usr_sche_id/". $i ."'>". $i ."</a></li>";
		        if($isnext==0)
		        {
		            $next="<li class='pagination-item'><a class='page-link' href='".base_url()."index.php/Schedule/schedule_wise_pro/$usr_sche_id/". $i ."'>Next</a></li>";
		            $isnext=1;
		        }

		    }


			$result = $this->ebay_model->get_record($schedule_id, $config["per_page"], $start);
			
			
			if($result == "false")
			{
				$data = array('data'=>'', 'state'=>$state, 'msginfo'=>$msginfo, 'links'=>'', 'id'=>$usr_sche_id);
				$this->load->view('ebay/index',$data);
			}
			else
			{
				//$links = $this->pagination->create_links();
				$links =$privious.$paginate.$next;
				$data = array(
							'data'	 =>$result->result(),
							'state'	 =>$state,
							'msginfo'=>$msginfo,
							'links'	 =>$links,
							'id'	 =>$usr_sche_id
					    	);
				$this->load->view('ebay/index',$data);	
			}
		}

	}

	// public function delete_schedule($pg=1)
	// {	
	// 	//print_r($this->session->userdata('token'));
	// 	//print_r($_SESSION['user_id']);
	// 	// $q = $this->db->query('
	// 	// 						SELECT
	// 	// 						  ss.schedule_id
	// 	// 						FROM
	// 	// 						  scraper_schedule as ss
	// 	// 						LEFT JOIN 
	// 	// 						  user_schedule us ON us.schedule_id = ss.schedule_id
	// 	// 						WHERE us.user_sch_id = '.$pg.' 
	// 	// 					');
	// 	// $res = $q->row();
	// 	// //print_r($res);
	// 	// $this->db->where(array('schedule_id', $res->schedule_id);
	// 	// //$this->db->where(array('schedule_id' => $res->schedule_id, 'user_id' => $this->session->get(''));
	// 	// $result = $this->db->delete('scraper_schedule');
	// 	//print_r($result);
	// 	//json_encode($result);
	// 	//redirect('shedule/index');

	// 	$q = $this->db->query('
	// 							DELETE
	// 								us.*
	// 							FROM
	// 								user_schedule AS us
	// 							LEFT JOIN
	// 								users u ON u.id = us.user_id
	// 							WHERE us.user_sch_id = '.$pg.' AND us.user_id IN (SELECT users.id FROM users WHERE users.user_id = '.$this->db->escape($_SESSION['user_id']).')
	// 						');
	// 	//$result = $q->row();
	// 	print_r($q);
	// 	json_encode(true);
	// 	// $tr = $this->db->where(array('user_sch_id' => $pg, 'user_id' => $_SESSION['user_id']));
	// 	// print_r($tr);
	// 	// $result = $this->db->delete('user_schedule');
	// 	// print_r($result);
	// }

	public function delete_schedule()
	{	
		$data = array(
						'sch_id' => $this->input->post('sch_id'),
						'session_user_id' => $this->db->escape($this->session->userdata('user_id'))	
					);
		
		$this->load->model('Schedule_model');
		echo $this->Schedule_model->delete_sch($data) ? '1' : '0';
		//($res);

	}
	
}
?>
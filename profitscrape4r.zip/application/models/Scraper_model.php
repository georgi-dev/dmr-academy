<?php
class Scraper_model extends CI_Model
{
	public function __construct()
	{
		parent:: __construct();
		$this->load->database();
	}

	public function scraper_m(){
		$q = $this->db->query('
								SELECT
								  u.id,
								  ss.*
								FROM
								  `scraper_schedule` as ss
								LEFT JOIN
								  `users` u ON(ss.`user_id` = u.`id`)
								WHERE updated_date < DATE_SUB(NOW(), INTERVAL 1 DAY) AND ss.status = 0
								ORDER BY
								  u.`jobs_running` ASC,
								  ss.`created_date` ASC
								LIMIT 10'
							);
		$jobs = $q->result();

		return $jobs;
	}



	public function runScraper($UserId, $schedule_id) 
	{
	    $Cmd = "php index.php ebay executelink_cron1 ". $UserId . " " . $schedule_id;
	 	
	    echo exec($Cmd);

	    $this->db->query('
		    				UPDATE
					    		`users`
					    	SET 
					    		`jobs_running` = (`jobs_running` + 1) 
					    	WHERE 
					    		`id` = '. $this->db->escape($UserId) .' 
	    				');

	}

	public function finishScraper($UserId)
	{
		$this->db->query('
	    					UPDATE 
		    					`users` 
		    				SET 
		    					`jobs_running` = (`jobs_running` - 1) 
		    				WHERE 
		    					`user_id` = '.$this->db->escape($UserId).'
	    				');
	}
}

?>
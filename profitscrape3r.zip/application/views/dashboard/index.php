

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta charset="UTF-8">
        <title>Ebay(USA) Product Details Scraper</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">
        
        <?php $this->load->view('includes/header');?>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
        <![endif]-->
<?php
  // if ($_SESSION['user_id']) {
  //   print_r($_SESSION);
  // }
  // else{
  //   print_r('check');
  //   redirect(base_url());
  // }
?>
<div class="navbar -dark -fixed-top -has-6-items">
      <div class="navbar-wrapper">
        <div class="sidebar-toggle hidden-lg-up hidden-xs-down" id="sidebar-toggle-navbar-brand" data-target="#sidebar"> <a href="javascript:void(0);"> <i class="fa fa-bars"> </i></a></div><a class="navbar-brand hidden-xs-down" href="dashboard.html"> 
          <h1>DSB Profit Scraper</h1></a>
        <ul class="navbar-nav -right">
          <li class="sidebar-toggle hidden-sm-up" id="sidebar-toggle" data-target="#sidebar"> <a href="javascript:void(0);"> <i class="fa fa-bars"> </i></a></li>
          <li> <a class="has-morph-dropdown" href="#notifications-dropdown"><i class="pe pe-bell"></i><span class="navbar-item-count">2</span></a></li>
          <li> <a class="has-morph-dropdown" href="#applications-dropdown"><i class="pe pe-keypad"></i></a></li>
          <li class="navbar-profile"> <a class="has-morph-dropdown" href="#profile-dropdown"><i class="pe pe-user"></i></a></li>
          <li class="sidebar-toggle" id="sidebar-secondary-toggle" data-target="#sidebar-secondary"> <a href="javascript:void(0);"> <i class="fa fa-ellipsis-v"> </i></a></li>
        </ul>
        <div class="morph-dropdown-wrapper -dark -right">
          <div class="morph-dropdown-list -links">
            <div class="morph-dropdown" id="notifications-dropdown">
              <div class="morph-content">
                <h3>Notifications</h3>
                <p class="_text-muted">Here's what happened while you were away.</p>
                <ul class="morph-links -small">
                  <li><a href="#"> <img src="resources/img/users/male3.jpg"/> <strong>John Doe </strong> has accepted your team invitation.<small>Just Now</small></a></li>
                  <li><a href="#"><img src="resources/img/users/female1.jpg"/> <strong>Gabriella Cruz </strong> has invited you to her event.<small>12 Hours Ago</small></a></li>
                  <li><a href="#"><img src="resources/img/users/female2.jpg"/> <strong>Sofia Owens </strong> has started following you.<small>1 Day Ago</small></a></li>
                </ul>
                <div class="_margin-top-1x"> <a class="btn -primary -block">View All Notifications</a></div>
              </div>
            </div>
            <div class="morph-dropdown" id="applications-dropdown">
              <div class="morph-content -gallery">
                <h3>Applications</h3>
                <p class="_text-muted">Open one of your connected social applications.</p>
                <ul class="morph-gallery">
                  <li> <a href="https://facebook.com/pixevil" target="_blank"><i class="fa fa-facebook-square"> </i>Facebook</a></li>
                  <li> <a href="https://twitter.com/pixevil" target="_blank"><i class="fa fa-twitter"> </i>Twitter</a></li>
                  <li> <a href="https://plus.google.com/+pixevil" target="_blank"> <i class="fa fa-google-plus"> </i>Google Plus</a></li>
                  <li> <a href="https://linkedin.com/company/pixevil" target="_blank"><i class="fa fa-linkedin"> </i>LinkedIn</a></li>
                  <li> <a href="https://github.com/pixevil" target="_blank"><i class="fa fa-github"> </i>GitHub</a></li>
                  <li> <a href="https://bitbucket.org" target="_blank" rel="nofollow"><i class="fa fa-bitbucket"> </i>BitBucket</a></li>
                  <li> <a href="https://slack.com/" target="_blank" rel="nofollow"><i class="fa fa-slack"> </i>Slack</a></li>
                  <li> <a href="https://dropbox.com/" target="_blank" rel="nofollow"><i class="fa fa-dropbox"> </i>DropBox</a></li>
                </ul>
                <div class="_margin-top-1x"><a class="btn -primary -block">View All Applications</a></div>
              </div>
            </div>
            <div class="morph-dropdown" id="profile-dropdown">
              <div class="morph-content -links">
                <div class="morph-profile"><img src="resources/img/users/male11.jpg"/>
                  <h4><?php echo $_SESSION['username']?></h4>
                  <p>Senior Web Developer </p>
                </div>
                <ul class="morph-links">
                  <li><a href="#">My Profile</a></li>
                  <li><a href="<?php echo base_url('index.php/profile/edit');?>">Account Edit</a></li>
                </ul>
                <div class="_margin-top-1x"> <a href="<?php echo base_url('index.php/auth/do_logout')?>"class="btn -primary -block">Sign Out</a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- END NAVBAR -->

      
      <!-- Sidebar -->
            <!-- Sidebar -->
<?php $this->load->view('includes/sidebar')?>
          
      <!-- Page content -->
  <div class="content -dark -with-left-sidebar -collapsible">

    <div class="container-fluid">
      <div class="row">
          <div class="page-heading -dark">
            <h1 style=" font-size: 30px;">Dashboard</h1>
          </div>
      </div>
    </div>
 

        <!-- Homepage Slider -->
        <br></br>
        <div class="-dark -with-left-sidebar -collapsible" id="contentpart">
         <div class="row">
          <div class="col-md-6">
            <div class="panel panel-default">
                <div class="panel-heading"><h4>Schedules</h4></div>
                <div class="panel-body">
                  <div class="col-md-6">
                    <h1 style="font-size: 50px;"><span class="glyphicon glyphicon-list"></span></h1>
                  </div>
                  <div class="col-md-6">
                    <h1 style="font-size: 50px;">
                      <?php echo $cnt1 = ($sche_cnt)?$sche_cnt:0; ?>
                    </h1>
                  </div>
                </div>
              </div>
          </div>
          <div class="col-md-6">
            <div class="panel panel-default">
                <div class="panel-heading"><h4>Products</h4></div>
                <div class="panel-body">
                  <div class="col-md-6">
                    <h1 style="font-size: 50px;"><span class="glyphicon glyphicon-shopping-cart"></span></h1>
                  </div>
                  <div class="col-md-6">
                    <h1 style="font-size: 50px;">
                      <?php echo $cnt2 = ($pro_cnt)?$pro_cnt:0; ?>
                    </h1>
                  </div>
                </div>
              </div>
          </div>
      </div>
      </div>
        
        

    <div class="text-center">
      <ul class="pagination pagination-lg">
      
        

      </ul>
    </div>


  </div>
      
      <!-- Footer -->
        <?php $this->load->view('includes/footer');?>
      

    </body>

    

</html>
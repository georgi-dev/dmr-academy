


    <div class="section section-breadcrumbs">
            <div class="container">
                <div class="row">
                    
                    <div class="col-md-10">
                          <div class="section section-breadcrumbs">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-3"></div>
                                        <div class="col-md-6">

                                          <div class="form-group">
                                            <label for="sel1">Search from:</label>
                                            <select name="searchfrom" class="form-control" id="searchfrom">
                                              <option value="UK">ebay.co.uk(UK)</option>
                                              <option value="USA">ebay.com(USA)</option>
                                            </select>
                                          </div>
                                          <div class="form-group">
                                            <label for="email">Seller ID:</label>
                                            <input type="text" name="sellerid" class="form-control" id="sellerid" placeholder="Enter Seller ID" value>
                                          </div>
                                          <div class="form-group">
                                            <label for="pwd">Keywords:</label>
                                            <input type="text" name="keyword" class="form-control" id="keyword" placeholder="Enter Keywords" value>
                                          </div>
                                          
                                          <div class="form-group">
                                              <label for="sel1">Items:</label>
                                              <select name="item" class="form-control" id="item">
                                                <option >All</option>
                                                <option >Sold Items</option>
                                                <option >Item For Sale</option>
                                              </select>
                                            </div>
                                          <div class="form-group" id="buttons">
                                         
                                        
                                        <span><a href="export_data.php" class="btn btn-danger" title="Export Data to CSV"><i class="glyphicon glyphicon-download-alt"></i> Export To CSV</a></span>
                                        
                                        </div>
                                        </div>
                                        <div class="col-md-3"></div>
                                    </div>
                                </div>
                            </div>
                        
                         

                    </div>
                    
                       <div class="col-md-2 text-right">
                        <a class="btn btn-danger navbar-btn" href="logout.php">Logout</a>
                        </div>
                        <!--</form>
                        <form action="collect_prodata.php" method="post" target="_blank">
                        <button class="btn btn-danger navbar-btn">Collect Data for link</button>
                        </form>
                        <a class="btn btn-danger navbar-btn" href="delete_asin.php" onclick="return deleteASIN()">Delete ASIN</a>
                        <a class="btn btn-danger navbar-btn" href="export_data.php">Export</a>
                        <a class="btn btn-danger navbar-btn" href="logout.php">Logout</a>
                        <form action="upload_data.php" enctype="multipart/form-data" method="post">
                            <input type="file" name="file" class="btn-file">
                            <input type="submit" name="upload" value="Import" class="btn btn-danger navbar-btn"> 
                        </form>-->
                    </div>
                    
                </div>
            </div>
 

        <!-- Homepage Slider -->
        <div class="container">
      <div class="row">
        <div class="col-md-12">
            
          
          
        </div>
      </div>
      </div>
        
        <table class="table">
  <thead class="thead-inverse">
    <tr>
      <th>Image</th>
      <!--<th>Product Link</th>-->
      <th>Product Title</th>
      <th>Price</th>
      <th>Item ID</th>
      <th>EAN</th>
      <th>MPN</th>
      <th>Sold Count</th>
      <th>Watchers</th>
      <th>Is Saller Top</th>
      <th>Saller</th>
      <th>Sold Date</th>
    </tr>
  </thead>
  <tbody>
    
  </tbody>
</table>

    <div class="text-center">
      <ul class="pagination pagination-lg">
     
        
      </ul>
    </div>


      
   
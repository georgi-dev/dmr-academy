

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta charset="UTF-8">
        <title>Ebay(USA) Product Details Scraper</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">
        <?php
          if($state==1)
          {
           echo "<meta http-equiv='refresh' content='10' >";
          }
        ?>
<?php $this->load->view('includes/header')?>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
        <![endif]-->
        
<div class="navbar -dark -fixed-top -has-6-items">
      <div class="navbar-wrapper">
        <div class="sidebar-toggle hidden-lg-up hidden-xs-down" id="sidebar-toggle-navbar-brand" data-target="#sidebar"> <a href="javascript:void(0);"> <i class="fa fa-bars"> </i></a></div><a class="navbar-brand hidden-xs-down" href="dashboard.html"> 
          <h1>DSB Profit Scraper</h1></a>
        <ul class="navbar-nav -right">
          <li class="sidebar-toggle hidden-sm-up" id="sidebar-toggle" data-target="#sidebar"> <a href="javascript:void(0);"> <i class="fa fa-bars"> </i></a></li>
          <li> <a class="has-morph-dropdown" href="#notifications-dropdown"><i class="pe pe-bell"></i><span class="navbar-item-count">2</span></a></li>
          <li> <a class="has-morph-dropdown" href="#applications-dropdown"><i class="pe pe-keypad"></i></a></li>
          <li class="navbar-profile"> <a class="has-morph-dropdown" href="#profile-dropdown"><i class="pe pe-user"></i></a></li>
          <li class="sidebar-toggle" id="sidebar-secondary-toggle" data-target="#sidebar-secondary"> <a href="javascript:void(0);"> <i class="fa fa-ellipsis-v"> </i></a></li>
        </ul>
        <ul class="" style="list-style:none  ;  line-height: 4.5;">
          <li class="d-inline-block px-3">
            <a href="<?php echo base_url('/Dashboard');?>"> <i class="pe pe-home"></i><span> Dashboard</span></a>
          </li>
          <li class="d-inline-block px-3">
            <a href="<?php echo base_url('/schedule');?>"> <i class="fa fa-list"></i><span> Schedule List</span></a>
          </li>
          <li class="d-inline-block px-3">
            <a href="<?php echo base_url('/schedule/add');?>"> <i class="fa fa-plus"></i><span> Add Schedule</span></a>
          </li>
        </ul>
        <div class="morph-dropdown-wrapper -dark -right">
          <div class="morph-dropdown-list -links">
            <div class="morph-dropdown" id="notifications-dropdown">
              <div class="morph-content">
                <h3>Notifications</h3>
                <p class="_text-muted">Here's what happened while you were away.</p>
                <ul class="morph-links -small">
                  <li><a href="#"> <img src="resources/img/users/male3.jpg"/> <strong>John Doe </strong> has accepted your team invitation.<small>Just Now</small></a></li>
                  <li><a href="#"><img src="resources/img/users/female1.jpg"/> <strong>Gabriella Cruz </strong> has invited you to her event.<small>12 Hours Ago</small></a></li>
                  <li><a href="#"><img src="resources/img/users/female2.jpg"/> <strong>Sofia Owens </strong> has started following you.<small>1 Day Ago</small></a></li>
                </ul>
                <div class="_margin-top-1x"> <a class="btn -primary -block">View All Notifications</a></div>
              </div>
            </div>
            <div class="morph-dropdown" id="applications-dropdown">
              <div class="morph-content -gallery">
                <h3>Applications</h3>
                <p class="_text-muted">Open one of your connected social applications.</p>
                <ul class="morph-gallery">
                  <li> <a href="https://facebook.com/pixevil" target="_blank"><i class="fa fa-facebook-square"> </i>Facebook</a></li>
                  <li> <a href="https://twitter.com/pixevil" target="_blank"><i class="fa fa-twitter"> </i>Twitter</a></li>
                  <li> <a href="https://plus.google.com/+pixevil" target="_blank"> <i class="fa fa-google-plus"> </i>Google Plus</a></li>
                  <li> <a href="https://linkedin.com/company/pixevil" target="_blank"><i class="fa fa-linkedin"> </i>LinkedIn</a></li>
                  <li> <a href="https://github.com/pixevil" target="_blank"><i class="fa fa-github"> </i>GitHub</a></li>
                  <li> <a href="https://bitbucket.org" target="_blank" rel="nofollow"><i class="fa fa-bitbucket"> </i>BitBucket</a></li>
                  <li> <a href="https://slack.com/" target="_blank" rel="nofollow"><i class="fa fa-slack"> </i>Slack</a></li>
                  <li> <a href="https://dropbox.com/" target="_blank" rel="nofollow"><i class="fa fa-dropbox"> </i>DropBox</a></li>
                </ul>
                <div class="_margin-top-1x"><a class="btn -primary -block">View All Applications</a></div>
              </div>
            </div>
            <div class="morph-dropdown" id="profile-dropdown">
              <div class="morph-content -links">
                <div class="morph-profile"><img src="resources/img/users/male11.jpg"/>
                  <h4><?php echo $_SESSION['username']?></h4>
                  <p>Senior Web Developer </p>
                </div>
                <ul class="morph-links">
                  <li><a href="#">My Profile</a></li>
                  <li><a href="#">Account Settings</a></li>
                </ul>
                <div class="_margin-top-1x"> <a href="<?php echo base_url('index.php/auth/do_logout')?>"class="btn -primary -block">Sign Out</a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- END NAVBAR -->

<div id="wrapper" class="active">
      
      <!-- Sidebar -->
            <!-- Sidebar -->

          

  <div id="page-content-wrapper"  style="height:300px;" >
  <form>

      <!-- Navigation & Logo-->
        
      <!-- Page content --><div class="content -dark -without-sidebar -collapsible" style="height: 0px;">

    <!-- <div class="container-fluid">
      <div class="row">
          <div class="page-heading -dark">
            <h1 style=" font-size: 30px;">Dashboard</h1>
          </div>
      </div>
    </div> -->
        <!-- Homepage Slider -->
        <div id="contentpart">
      <div>
        <div class="col -md-12">
          
           <div class="panel panel-primary" style="border-color:#bdc6c6;">
              <div class="panel-heading" style="background-color:#bdc6c6;border-color:#bdc6c6;"><h4 style="color:black;">Ebay Product Search Details</h4></div>
              <div class="panel-body">
                <div class="row">
                  <div class="col -md-6">
                    <span id='label'><b><em>Ebay Country :</em></b> <?php if($msginfo['searchfrom']!="")
                      echo $msginfo['searchfrom']; ?></span><br>
                    <span id='label'><b><em>Searched Keyword :</em></b> <?php if($msginfo['keyword']!="")
                      echo $msginfo['keyword']; ?></span><br>
                    <span id='label'><b><em>Searched Seller :</em></b> <?php if($msginfo['seller']!="")
                      echo $msginfo['seller']; ?></span><br>
                    <span id='label'><b><em>Item Type:</em></b> <?php if($msginfo['item']!="")
                      echo $msginfo['item']; ?></span><br>
                  </div>

                  <div class="col -md-6">
                    <span id='label'><b>Ebay Page Result :</b> <?php if($msginfo['pageresult']!="")
                      echo $msginfo['pageresult']; ?></span><br>
                    <span id='label'><b>Scraped Result :</b> <?php if($msginfo['scrapeditem']!="")
                      echo $msginfo['scrapeditem']; ?></span><br>
                   
                  </div>  
                </div>
              </div>
            </div>
          
        </div>
      </div>

      </div>
        
        

  </form>
  </div>
      
</div>  
        
      <div class="content panel -dark table-responsive">
          

          <input type="hidden" name="schid" id="schid" value="<?php echo $id; ?>">
          

          <table class="table -dark col -xl-12">
            <thead>
              <tr>
                <th>Image</th>
                <th>Product Name</th>
                <th>Sell Price</th>
                <!-- <th>SKU</th> -->
                <th>Sold Items</th>
                <th>Watchers</th>
                <!-- <th>Seller Top</th> -->
                <!-- <th>Seller Name</th> -->
                <!-- <th>Date of Sold</th> -->
                <th>EAN / MPN / UPC</th>

                <th>ISBN</th>
              </tr>
            </thead>

            <tbody>
            <?php
              
              if($data)
              {
                  foreach ($data as $row)
                  {
                    echo "<tr style='font-size:13px;'>
                        <td ><a target='_blank' href='".$row->url."'><img width='50' height='50' class='img-responsive' src='".$row->pro_img."'></a></td>
                        <td class=''><a target='_blank' href='".$row->url."'>".wordwrap($row->pro_title, 40, "<br />\n")."</a></td>
                        <td class=''>".$row->pro_price."</td>
                        <td class=''>".$row->sold_count."</td>
                        <td class=''>".$row->watchers."</td>
                        <td class=''>
                          <b>EAN:</b><span>".$row->ean."</span></br>
                           <b>MPN: </b><span>".$row->mpn."</span></br>
                           <b>UPC: </b><span>".$row->upc."</span></br>
                          
                        <td class=''>".$row->isbn."</td>
                      </tr>"; 
                      
                      
                  }    
              }

            ?>
            </tbody>
          </table>

            <div class="text-center">

              <ul class="pagination -dark">
              
                <?php echo $links; ?>

              </ul>
            </div>


      </div>

      
      <!-- Footer -->
      <?php $this->load->view('includes/footer')?>

    </body>

    <script>
  function deleteASIN() 
  {
      
      var r = confirm("You want to Delete ASIN No ...?");
      if (r == true)
        return true;
      else
        return false;
      
  }
  
</script>
<script>
$(document).ready(function(){
    var id = $('#schid').val();
    
    var asd = $(".text-center > ul > a").attr('href');

    
});



</script>


</html>
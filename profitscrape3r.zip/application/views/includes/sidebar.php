<!-- <div id="menu" class="hidden-print"> -->
    
            <!-- Brand -->
            <!-- <a href="index.html?lang=en&amp;layout_type=fixed&amp;menu_position=menu-left&amp;style=style-light" class="appbrand">DSB <span> Profit Scraper</span></a> -->
          
            <!-- Scrollable menu wrapper with Maximum height -->
            <!-- <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 1590px;"><div class="slim-scroll" data-scroll-height="800px" style="overflow: hidden; width: auto; height: 1590px;"> -->
            
            <!-- Regular Size Menu -->
            <!-- <ul class="menu-0"> -->
            
                     <!--                <li class="glyphicons display"><a href="<?php echo base_url('index.php/Dashboard') ?>" title="Scrap from Amazon.com"><i></i><span>Dashboard</span></a></li>
              <li class="glyphicons"><a href="<?php echo base_url('index.php/schedule') ?>" title="Scrap from Amazon.com">Schedule List<span class="sub_icon glyphicon glyphicon-link"></span></a></li>
              <li class="glyphicons"><a href="<?php echo base_url('index.php/schedule/add') ?>" title="Scrap from Amazon.com">Add Schedule<span class="sub_icon glyphicon glyphicon-link"></span></a></li>
              <li class="glyphicons"><a href="<?php echo base_url('index.php/profile') ?>" title="Scrap from Amazon.com">Profile<span class="sub_icon glyphicon glyphicon-link"></span></a></li>
              <li class="glyphicons"><a href="<?php echo base_url('index.php/login/do_logout') ?>">LogOut<span class="sub_icon glyphicon glyphicon-log-out"></span></a></li>
                      -->
                      <!-- Menu Regular Item -->
              <!-- <li class="glyphicons display"><a href="<?php echo base_url('index.php/Dashboard') ?>"><i></i><span>Dashboard</span></a></li> -->
              <!-- <li class="glyphicons display"><a href="<?php echo base_url('index.php/schedule') ?>"><i></i><span>Schedule List</span></a></li> -->
              <!-- <li class="glyphicons display"><a href="<?php echo base_url('index.php/schedule/add') ?>"><i></i><span>Add Schedule</span></a></li> -->
              <!-- <li class="glyphicons display"><a href="<?php echo base_url('index.php/profile') ?>"><i></i><span>Profile</span></a></li> -->
              <!-- <li class="glyphicons display"><a href="<?php echo base_url('index.php/auth/do_logout') ?>"><i></i><span>LogOut</span></a></li> -->
              
              <!-- Exmaples Submenu Level 1 -->
            <!-- </ul> -->
            <!-- <div class="clearfix"></div> -->

            <!-- <div class="separator bottom"></div> -->
                  
            <!-- </div><div class="slimScrollBar ui-draggable" style="background: rgb(0, 0, 0); width: 7px; position: absolute; top: 0px; opacity: 0.4; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 1590px;"></div><div class="slimScrollRail" style="width: 7px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 1px;"></div></div> -->
            <!-- // Scrollable Menu wrapper with Maximum Height END -->
      
        <!-- </div> -->


            <div class="sidebar -dark -left -slideable -collapsible" id="sidebar" style="height:300px;">
      <div class="scrollable">
        <div class="scrollable-content">
          <div class="sidebar-wrapper"> 
            <ul class="sidebar-menu metismenu">
              <li class="sidebar-heading"> Application
              </li>
                <li>
                  <a href="<?php echo base_url('index.php/Dashboard'); ?>"> <i class="pe pe-home"></i><span> Dashboard</span></a>
                </li>
                <li>
                  <a href="<?php echo base_url('index.php/schedule'); ?>"> <i class="pe pe-home"></i><span> Schedule List</span></a>
                </li>
                <li>
                  <a href="<?php echo base_url('index.php/schedule/add'); ?>"> <i class="pe pe-home"></i><span> Add Schedule</span></a>
                </li>

              
            </ul>
          </div>
        </div>
      </div>
    </div>
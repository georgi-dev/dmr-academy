

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta charset="UTF-8">
        <title>Ebay(USA) Product Details Scraper</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">
        
        <?php $this->load->view('includes/header')?>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
        <![endif]-->
        
<div class="navbar -dark -fixed-top -has-6-items">
      <div class="navbar-wrapper">
        <div class="sidebar-toggle hidden-lg-up hidden-xs-down" id="sidebar-toggle-navbar-brand" data-target="#sidebar"> <a href="javascript:void(0);"> <i class="fa fa-bars"> </i></a></div><a class="navbar-brand hidden-xs-down" href="dashboard.html"> 
          <h1>Volta</h1></a>
        <ul class="navbar-nav -right">
          <li class="sidebar-toggle hidden-sm-up" id="sidebar-toggle" data-target="#sidebar"> <a href="javascript:void(0);"> <i class="fa fa-bars"> </i></a></li>
          <li> <a class="has-morph-dropdown" href="#notifications-dropdown"><i class="pe pe-bell"></i><span class="navbar-item-count">2</span></a></li>
          <li> <a class="has-morph-dropdown" href="#applications-dropdown"><i class="pe pe-keypad"></i></a></li>
          <li class="navbar-profile"> <a class="has-morph-dropdown" href="#profile-dropdown"><i class="pe pe-user"></i></a></li>
          <li class="sidebar-toggle" id="sidebar-secondary-toggle" data-target="#sidebar-secondary"> <a href="javascript:void(0);"> <i class="fa fa-ellipsis-v"> </i></a></li>
        </ul>
        <div class="morph-dropdown-wrapper -dark -right">
          <div class="morph-dropdown-list -links">
            <div class="morph-dropdown" id="notifications-dropdown">
              <div class="morph-content">
                <h3>Notifications</h3>
                <p class="_text-muted">Here's what happened while you were away.</p>
                <ul class="morph-links -small">
                  <li><a href="#"> <img src="resources/img/users/male3.jpg"/> <strong>John Doe </strong> has accepted your team invitation.<small>Just Now</small></a></li>
                  <li><a href="#"><img src="resources/img/users/female1.jpg"/> <strong>Gabriella Cruz </strong> has invited you to her event.<small>12 Hours Ago</small></a></li>
                  <li><a href="#"><img src="resources/img/users/female2.jpg"/> <strong>Sofia Owens </strong> has started following you.<small>1 Day Ago</small></a></li>
                </ul>
                <div class="_margin-top-1x"> <a class="btn -primary -block">View All Notifications</a></div>
              </div>
            </div>
            <div class="morph-dropdown" id="applications-dropdown">
              <div class="morph-content -gallery">
                <h3>Applications</h3>
                <p class="_text-muted">Open one of your connected social applications.</p>
                <ul class="morph-gallery">
                  <li> <a href="https://facebook.com/pixevil" target="_blank"><i class="fa fa-facebook-square"> </i>Facebook</a></li>
                  <li> <a href="https://twitter.com/pixevil" target="_blank"><i class="fa fa-twitter"> </i>Twitter</a></li>
                  <li> <a href="https://plus.google.com/+pixevil" target="_blank"> <i class="fa fa-google-plus"> </i>Google Plus</a></li>
                  <li> <a href="https://linkedin.com/company/pixevil" target="_blank"><i class="fa fa-linkedin"> </i>LinkedIn</a></li>
                  <li> <a href="https://github.com/pixevil" target="_blank"><i class="fa fa-github"> </i>GitHub</a></li>
                  <li> <a href="https://bitbucket.org" target="_blank" rel="nofollow"><i class="fa fa-bitbucket"> </i>BitBucket</a></li>
                  <li> <a href="https://slack.com/" target="_blank" rel="nofollow"><i class="fa fa-slack"> </i>Slack</a></li>
                  <li> <a href="https://dropbox.com/" target="_blank" rel="nofollow"><i class="fa fa-dropbox"> </i>DropBox</a></li>
                </ul>
                <div class="_margin-top-1x"><a class="btn -primary -block">View All Applications</a></div>
              </div>
            </div>
            <div class="morph-dropdown" id="profile-dropdown">
              <div class="morph-content -links">
                <div class="morph-profile">
                  <h4><?php echo $_SESSION['username']?></h4>
                  <p>Senior Web Developer </p>
                </div>
                <ul class="morph-links">
                  <li><a href="#">My Profile</a></li>
                  <li><a href="#">Account Settings</a></li>
                </ul>
                <div class="_margin-top-1x"> <a href=""class="btn -primary -block">Sign Out</a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<div id="wrapper" class="active">
      
      <!-- Sidebar -->
            <!-- Sidebar -->
<?php $this->load->view('includes/sidebar')?>
          
      <!-- Page content -->
  <div class="content -dark -with-left-sidebar -collapsible">

            <div class="container-fluid">
                <div class="row">
                    <div class="page-heading -dark">
                      <h1 style=" font-size: 30px;">Add Schedule</h1>
                       </div>
                    </div>
                    
                </div>
            
      
      <br><br>
        <!-- Homepage Slider -->
      <div class="content -dark -with-left-sidebar -collapsible" id='contentpart'>
        <div class="row">
        <div class="col-md-1"></div>
          <form action="" method="post">
          <div class="col-md-12">
            <?php if ($this->session->flashdata('message')) { ?>
            <div class="alert alert-warning"><?php echo $this->session->flashdata('message'); ?></div><br>
            <?php } ?>
              <div class="form-group">
                <label for="sel1">Ebay Country:</label>
                <select name="searchfrom" class="form-control" id="searchfrom" required="">
                  <option value="UK">ebay.co.uk(UK)</option>
                  <option value="USA">ebay.com(USA)</option>
                </select>
                <div style="color:red;"><?php echo form_error('searchfrom')?form_error('searchfrom'):""; ?></div>
              </div>
              <div class="form-group">
                <label for="email">Ebay Seller ID:</label>
                <input type="text" name="sellerid" class="form-control" id="sellerid" placeholder="Enter Seller ID" value="">
                <div style="color:red;"><?php echo form_error('sellerid')?form_error('sellerid'):""; ?></div>
              </div>
              <div class="form-group">
                <label for="pwd">Search Keyword:</label>
                <input type="text" name="keyword" class="form-control" id="keyword" placeholder="Enter Keywords" value="">
                <div style="color:red;"><?php echo form_error('keyword')?form_error('keyword'):""; ?></div>
              </div>
              <div class="form-group">
                <label for="sel1">Item Type:</label>
                <select name="item" class="form-control" id="item" required="">
                  <option value="All">All</option>
                  <option value="Sold Items">Sold Items</option>
                  <option value="Item For Sale">Item For Sale</option>
                </select>
                <div style="color:red;"><?php echo form_error('item')?form_error('item'):""; ?></div>
              </div>
              <button type="submit" class="btn btn-info" name="add">Add Schedule</button>
          </div>
          </form>

        </div>
      </div>
      

  </div>
      
</div>  
        


      
      <!-- Footer -->
      <?php $this->load->view('includes/footer')?>

    </body>

    <script>
  function deleteASIN() 
  {
      
      var r = confirm("You want to Delete ASIN No ...?");
      if (r == true)
        return true;
      else
        return false;
      
  }
  
</script>
<script>
function loadDoc() {

  var xhttp = new XMLHttpRequest();
  var searchfrom=document.getElementById("searchfrom").value;
  var sellerid=document.getElementById("sellerid").value;
  var keyword=document.getElementById("keyword").value;
  var item=document.getElementById("item").value;
  sellerid=encodeURIComponent(sellerid);
  keyword=encodeURIComponent(keyword);
  item=encodeURIComponent(item);
  searchfrom=encodeURIComponent(searchfrom);

  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
     //alert(this.responseText);
      $("#msg").html(this.responseText);
      $("#msg").attr("class", "alert alert-success");
      $("#ermsg").focus();
    }
  };
  $('#buttons').hide();
  //$('#display').show();
  xhttp.open("POST", "<?php echo base_url(); ?>index.php/ebay/execute_scraper", true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send("sellerid="+sellerid+"&keyword="+keyword+"&item="+item+"&searchfrom="+searchfrom);
  setInterval(function(){location.reload();},5000);

}

function stopScript(){
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
     //alert(this.responseText);
      $("#msg").html(this.responseText);
      $("#msg").attr("class", "alert alert-success");
      $("#ermsg").focus();
    }
  };

  xhttp.open("POST", "<?php echo base_url(); ?>index.php/ebay/stop_execution", true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send();
  setInterval(function(){location.reload();},1000);
}


</script>


</html>
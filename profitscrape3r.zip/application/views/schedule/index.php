<!DOCTYPE html>
<!--[if lt IE 7]>      
<html class="no-js lt-ie9 lt-ie8 lt-ie7">
<![endif]-->
<!--[if IE 7]>         
<html class="no-js lt-ie9 lt-ie8">
<![endif]-->
<!--[if IE 8]>         
<html class="no-js lt-ie9">
<![endif]-->
<!--[if gt IE 8]><!--> 
<html class="no-js">
  <!--<![endif]-->
  <head>
     <meta charset="utf-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
     <meta charset="UTF-8">
     <title>Ebay(USA) Product Details Scraper</title>
     <meta name="description" content="">
     <meta name="viewport" content="width=device-width">
<?php $this->load->view('includes/header')?>
  </head>
  <body>
     <!--[if lt IE 7]>
     <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
     <![endif]-->
     <?php
        if ($_SESSION) {
          # code...
        }
        else{
        
          die();
        }
        ?>
     <div id="wrapper" class="active">
      <div class="navbar -dark -fixed-top -has-6-items">
      <div class="navbar-wrapper">
        <div class="sidebar-toggle hidden-lg-up hidden-xs-down" id="sidebar-toggle-navbar-brand" data-target="#sidebar"> <a href="javascript:void(0);"> <i class="fa fa-bars"> </i></a></div><a class="navbar-brand hidden-xs-down" href="dashboard.html"> 
          <h1>Volta</h1></a>
        <ul class="navbar-nav -right">
          <li class="sidebar-toggle hidden-sm-up" id="sidebar-toggle" data-target="#sidebar"> <a href="javascript:void(0);"> <i class="fa fa-bars"> </i></a></li>
          <li> <a class="has-morph-dropdown" href="#notifications-dropdown"><i class="pe pe-bell"></i><span class="navbar-item-count">2</span></a></li>
          <li> <a class="has-morph-dropdown" href="#applications-dropdown"><i class="pe pe-keypad"></i></a></li>
          <li class="navbar-profile"> <a class="has-morph-dropdown" href="#profile-dropdown"><i class="pe pe-user"></i></a></li>
          <li class="sidebar-toggle" id="sidebar-secondary-toggle" data-target="#sidebar-secondary"> <a href="javascript:void(0);"> <i class="fa fa-ellipsis-v"> </i></a></li>
        </ul>
        <div class="morph-dropdown-wrapper -dark -right">
          <div class="morph-dropdown-list -links">
            <div class="morph-dropdown" id="notifications-dropdown">
              <div class="morph-content">
                <h3>Notifications</h3>
                <p class="_text-muted">Here's what happened while you were away.</p>
                <ul class="morph-links -small">
                  <li><a href="#"> <img src="resources/img/users/male3.jpg"/> <strong>John Doe </strong> has accepted your team invitation.<small>Just Now</small></a></li>
                  <li><a href="#"><img src="resources/img/users/female1.jpg"/> <strong>Gabriella Cruz </strong> has invited you to her event.<small>12 Hours Ago</small></a></li>
                  <li><a href="#"><img src="resources/img/users/female2.jpg"/> <strong>Sofia Owens </strong> has started following you.<small>1 Day Ago</small></a></li>
                </ul>
                <div class="_margin-top-1x"> <a class="btn -primary -block">View All Notifications</a></div>
              </div>
            </div>
            <div class="morph-dropdown" id="applications-dropdown">
              <div class="morph-content -gallery">
                <h3>Applications</h3>
                <p class="_text-muted">Open one of your connected social applications.</p>
                <ul class="morph-gallery">
                  <li> <a href="https://facebook.com/pixevil" target="_blank"><i class="fa fa-facebook-square"> </i>Facebook</a></li>
                  <li> <a href="https://twitter.com/pixevil" target="_blank"><i class="fa fa-twitter"> </i>Twitter</a></li>
                  <li> <a href="https://plus.google.com/+pixevil" target="_blank"> <i class="fa fa-google-plus"> </i>Google Plus</a></li>
                  <li> <a href="https://linkedin.com/company/pixevil" target="_blank"><i class="fa fa-linkedin"> </i>LinkedIn</a></li>
                  <li> <a href="https://github.com/pixevil" target="_blank"><i class="fa fa-github"> </i>GitHub</a></li>
                  <li> <a href="https://bitbucket.org" target="_blank" rel="nofollow"><i class="fa fa-bitbucket"> </i>BitBucket</a></li>
                  <li> <a href="https://slack.com/" target="_blank" rel="nofollow"><i class="fa fa-slack"> </i>Slack</a></li>
                  <li> <a href="https://dropbox.com/" target="_blank" rel="nofollow"><i class="fa fa-dropbox"> </i>DropBox</a></li>
                </ul>
                <div class="_margin-top-1x"><a class="btn -primary -block">View All Applications</a></div>
              </div>
            </div>
            <div class="morph-dropdown" id="profile-dropdown">
              <div class="morph-content -links">
                <div class="morph-profile"><img src="resources/img/users/male11.jpg"/>
                  <h4>John Doe</h4>
                  <p>Senior Web Developer </p>
                </div>
                <ul class="morph-links">
                  <li><a href="#">My Profile</a></li>
                  <li><a href="#">Account Settings</a></li>
                </ul>
                <div class="_margin-top-1x"> <a class="btn -primary -block">Sign Out</a></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
        <!-- Sidebar -->
        <?php $this->load->view('includes/sidebar')?>
        <!-- Page content -->
        <div class="content -dark -with-left-sidebar -collapsible">
           <!-- Navigation & Logo-->
           <div class="container-fluid">
                <div class="row">
                    <div class="page-heading -dark">
                      <h1 style=" font-size: 30px;">Schedule List</h1>
                       </div>
                    </div>
                    
                </div>
           <!-- Homepage Slider -->
           <br>
           <div class="-dark -with-left-sidebar -collapsible " >
              <?php if ($this->session->flashdata('message')) { ?>
              <h4 class="alert alert-primary"><?php echo $this->session->flashdata('message'); ?></h4>
              <br>
              <?php } ?>
              <div class="col -xl-12">
                 <?php if($data){ ?>
                 <div class="page-heading -dark">
                    <!-- Widget -->
                    <div class="widget">
                       <!-- Widget heading -->
                       <div class="widget-head">
                          <h4 class="">Data Table</h4>
                       </div>
                       <!-- // Widget heading END -->
                       <div class="widget-body">
                          <!-- Table -->
                          <table class="table -dark -striped">
                             <!-- Table heading -->
                             <thead>
                                <tr>
                                   <th>Ebay Country</th>
                                   <!--<th>Product Link</th>-->
                                   <th>Ebay Seller ID</th>
                                   <th>Search Keyword</th>
                                   <th>Item Type</th>
                                   <th>Action</th>
                                </tr>
                             </thead>
                             <!-- // Table heading END -->
                             <!-- Table body -->
                             <tbody>
                                <?php
                                   if($data)
                                   {
                                     //print_r($data);
                                     $state=""; $seller_name="";
                                       foreach ($data as $row)
                                       {
                                         if($row->is_active==1)
                                           $state = "Deactive";
                                         if($row->is_active==2)
                                           $state = "Active";
                                         if($row->seller_name == "")
                                           $seller_name = "--";
                                         else
                                           $seller_name = $row->seller_name;
                                         if($row->keyword == "")
                                           $keyword = "--";
                                         else
                                           $keyword = $row->keyword;
                                   
                                         echo "<tr>
                                             <form>
                                             <td>".$row->search_from."</td>
                                             <td>".$seller_name."</td>
                                             
                                             <td>".$keyword."</td>
                                             <td>".$row->item."</td>
                                             
                                             <td class='center'><button type='submit' class='btn-action btn-default' formaction='".base_url('index.php/Schedule/schedule_wise_pro/'.$row->user_sch_id)."'><i class=\"fa fa-eye\"> </i> View</button></td>


                                             <td><a class=\"btn -danger\" href=\"#\"> <i class=\"fa fa-exclamation-circle\"> </i> Delete </a>
                                             <td class='center'><input type='hidden' name=\"sch_id\" value='".$row->user_sch_id."'/><button type='btn' class='btn delete_schedule btn-action glyphicons remove_2 btn-danger'>Delete</button></td>
                                             
                                             </form>
                                           </tr>"; 
                                           
                                           
                                       }
                                       echo "<div class='status alert alert-success' style='font-size:20px;width:300px;display:none;'' '></div>";    
                                   }
                                   
                                   ?>
                             </tbody>
                             <!-- // Table body END -->
                          </table>
                          <!-- // Table END -->
                       </div>
                    </div>
                    <!-- // Widget END -->
                 </div>
                 <!-- // innerLR END -->

<!--                  <div class="pagination pagination-right margin-none">
                  <ul>
                    <li class="disabled"><a href="#">&laquo;</a></li>
                    <li class="active"><a href="#">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">&raquo;</a></li>
                  </ul>
                </div> -->
                 <?php } else echo "<span class='alert alert-default'> No Schedule Available!! </span>"; ?>
              </div>
           </div>
<!--            <div class="text-center">
              <ul class="pagination pagination-lg">
                 <?php if($data){ echo $links; }?>
              </ul>
           </div> -->
        </div>
     </div>
     <!-- Footer -->
     <?php $this->load->view('includes/footer')?>
  <script>
     $('.delete_schedule').click(function(e){
       e.preventDefault();
     
       var current = $(this).parent().parent();
       var schedule_id = $(this).siblings().val();
     
       $.ajax({
           type: "POST",
           url: "<?php echo base_url()?>" + "index.php/Schedule/delete_schedule/",
           dataType: 'json',
           data:{sch_id:schedule_id},
           success: function(response){
           console.log("DELETED");
           console.log(this);
           $('.status').text("Row was deleted succesfuly").show();
           $('.status').fadeOut(2000);
           current.hide();
           },
           error: function(error){
             console.log(error);
           } 
       });
     
     });
     
     // var sch_id = $('.delete_schedule').val();
     // var that = schedule_id;
     
     //   $.ajax({
     //       type: "POST",
     //       url: "<?php echo base_url()?>" + "index.php/Schedule/delete_schedule/" + that + "",
     //       dataType: 'json',
     //       success: function(response){
     //       console.log("DELETED");
     //       console.log(that);
     //       //$('input').val(that).parent().parent().hide();
     //       console.log($('input').val(that).parent());
     //       },
     //       error: function(response){
     //         console.log(response);
     //       } 
     //   });
     
     
     
     
     
     
     
     
     
     
     function loadDoc() {
     
     var xhttp = new XMLHttpRequest();
     var searchfrom=document.getElementById("searchfrom").value;
     var sellerid=document.getElementById("sellerid").value;
     var keyword=document.getElementById("keyword").value;
     var item=document.getElementById("item").value;
     sellerid=encodeURIComponent(sellerid);
     keyword=encodeURIComponent(keyword);
     item=encodeURIComponent(item);
     searchfrom=encodeURIComponent(searchfrom);
     
     xhttp.onreadystatechange = function() {
       if (this.readyState == 4 && this.status == 200) {
        //alert(this.responseText);
         $("#msg").html(this.responseText);
         $("#msg").attr("class", "alert alert-success");
         $("#ermsg").focus();
       }
     };
     $('#buttons').hide();
     //$('#display').show();
     xhttp.open("POST", "<?php echo base_url(); ?>index.php/ebay/execute_scraper", true);
     xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
     xhttp.send("sellerid="+sellerid+"&keyword="+keyword+"&item="+item+"&searchfrom="+searchfrom);
     setInterval(function(){location.reload();},5000);
     
     }
     
     function stopScript(){
     var xhttp = new XMLHttpRequest();
     xhttp.onreadystatechange = function() {
       if (this.readyState == 4 && this.status == 200) {
        //alert(this.responseText);
         $("#msg").html(this.responseText);
         $("#msg").attr("class", "alert alert-success");
         $("#ermsg").focus();
       }
     };
     
     xhttp.open("POST", "<?php echo base_url(); ?>index.php/ebay/stop_execution", true);
     xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
     xhttp.send();
     setInterval(function(){location.reload();},1000);
     }
     
     
  </script>
</html>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta charset="UTF-8">
        <title>Profile</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">
        
        <link rel="stylesheet" href="<?php echo base_url('public/css/bootstrap.min.css'); ?>">
        <link rel="stylesheet" href="<?php echo base_url(); ?>public/css/icomoon-social.css">
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,600,800' rel='stylesheet' type='text/css'>

        <link rel="stylesheet" href="<?php echo base_url('public/css/leaflet.css'); ?>" />
    <!--[if lte IE 8]>
        <link rel="stylesheet" href="css/leaflet.ie.css" />
    <![endif]-->
    <!-- <link rel="stylesheet" href="<?php echo base_url('public/css/main.css'); ?>"> -->
     <link rel="stylesheet" href="<?php echo base_url('public/template/common/theme/css/style-light.css'); ?>">
     <link rel="stylesheet" href="<?php echo base_url('public/template/common/theme/css/glyphicons.css'); ?>">
    <link rel="stylesheet" href="<?php echo base_url('public/css/sidebar.css'); ?>">

        <script src="<?php echo base_url('public/js/modernizr-2.6.2-respond-1.1.0.min.js'); ?>"></script>
        <style type="text/css">
          .mainmenu-wrapper{
        background-color: #5bc0de;
          }

        </style>
    </head>
    <body>





<div id="wrapper" class="active">
  <div class="section section-breadcrumbs">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1>This is profile page</h1>
            <h1>Hello <?php echo $_SESSION['username']?></h1>
          </div>
        </div>
      </div>
    </div>
<?php $this->load->view('includes/sidebar')?>
		
</div>


<div class="footer">
        <div class="container">
          
          <div class="row">
            <div class="col-md-12">
              <div class="footer-copyright">&copy; 2017.</div>
            </div>
          </div>
        </div>
      </div>

        <!-- Javascripts -->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="public/js/jquery-1.9.1.min.js"><\/script>')</script>
        <script src="<?php echo base_url('public/js/bootstrap.min.js'); ?>"></script>
        <script src="http://cdn.leafletjs.com/leaflet-0.5.1/leaflet.js"></script>
        <script src="<?php echo base_url('public/js/jquery.fitvids.js'); ?>"></script>
        <script src="<?php echo base_url('public/js/jquery.sequence-min.js'); ?>"></script>
        <script src="<?php echo base_url('public/js/jquery.bxslider.js'); ?>"></script>
        <script src="<?php echo base_url('public/js/main-menu.js'); ?>"></script>
        <script src="<?php echo base_url('public/js/template.js'); ?>"></script>

    </body>

    <script>


    // function registration(){

    //   $('#registration').click(function(e){
    //     e.preventDefault();
    //     $.ajax({
    //         type: "POST",
    //         url: "<?php echo base_url()?>" + "index.php/Login/create_account/",
    //         dataType: 'json',
    //         success: function(response){
    //         },
    //         error: function(error){
    //           console.log(error);
    //         } 
    //     });

    //   });
    // }


  
</script>
<script>

function isMatch()
{
  var pass = $('#login-password').val();
  var cnfpass = $('#login-cnfpassword').val();
  
  if(pass != cnfpass)
  {
    $('#err').html('Password Mismatch with Confirm Password...');
    return false;
  }
  return true;
}





</script>


</html>
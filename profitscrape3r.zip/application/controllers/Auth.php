<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{

		parent:: __construct();

		$this->load->database();

		$this->load->library('pagination');	
		$this->load->library('session');
		$this->load->library('form_validation');
		$this->load->helper('url');

	}

	
	// public function index()
	// {
		 
	// 	//$this->layout_view="layout/auth_view";
	// 	//$this->template = 'layout/auth_view';
		
	// 	//$this->load->helper('url');
	// 	$data = array('message'=>'');
	// 	$result="";
	// 	//$this->load->view('auth/index',$data);
	// 	if($this->input->post('auth'))
	// 	{
	// 		$this->form_validation->set_rules('userid', 'User', 'required');

	// 		$this->form_validation->set_rules('password', 'Password', 'required');

	// 		$this->form_validation->set_error_delimiters('<div class="alert alert-danger">', '</div>');
	// 		if($this->form_validation->run()==TRUE)
	// 		{
				
	// 			$userid = $this->input->post('userid');
	// 			$password = $this->input->post('password');
				
	// 			$this->load->model("Auth_model");
	// 			$result=$this->Auth_model->auth_do($userid,$password);
				
	// 			if($result == "false")
	// 			{
	// 				$data = array(
	// 				    'message' => '<div class="alert alert-danger">Invalid Userid OR Password...!</div>'
	// 				);
	// 			}
	// 			else
	// 			{
	// 				if($result=="deactive")
	// 				{
	// 					$data = array(
	// 					    'message' => '<div class="alert alert-danger">Your Accont is Deactiveted by Admin.</div>'
	// 					);
	// 				}
	// 				else
	// 				{
	// 					$session = md5($userid.mt_rand(0,10000));

	// 					$this->session->set_userdata('user_id', $userid);

	// 					$data=array('token'=>$session);
	// 					$result = $this->Auth_model->store_token($data, $userid, $password);

						
	// 					$this->session->sess_expiration = '604800';// expires in 2 days
	// 					$this->session->sess_expire_on_close = 'false';
	// 					//$this->session->set_userdata($session);
	// 					$this->session->set_userdata('token', $session);
						
	// 					//redirect('ebay', 'refresh');
	// 					redirect('Dashboard', 'refresh');
						
	// 				}
	// 			}

	// 		}
	// 	}
		
	// 		$this->load->view('auth/index',$data);



		
	// }

	public function index()
	{
		 
		//$this->layout_view="layout/auth_view";
		//$this->template = 'layout/auth_view';
		
		//$this->load->helper('url');
		$data = array('message'=>'');
		$result="";
		//$this->load->view('auth/index',$data);
		
			$this->form_validation->set_rules('email', 'Email', 'required');

			$this->form_validation->set_rules('password', 'Password', 'required');

			$this->form_validation->set_error_delimiters('<div class="alert alert-danger">', '</div>');
			if($this->form_validation->run()==TRUE)
			{
				
				$userid = $this->input->post('email');
				$password = $this->input->post('password');
				
				$this->load->model("Auth_model");
				$result=$this->Auth_model->sign_in($userid,$password);
				
				if($result == "false")
				{
					$data = array(
					    'message' => '<div class="alert alert-danger">Invalid Userid OR Password...!</div>'
					);
				}
				else
				{
					if($result=="deactive")
					{
						$data = array(
						    'message' => '<div class="alert alert-danger">Your Account is Deactiveted by Admin.</div>'
						);
					}
					else if ($result=="exists") {
					
						$session = md5($userid.mt_rand(0,10000));
						$data = $this->Auth_model->get_user($userid);
						print_r($data);
						$this->session->set_userdata('user_id', $userid);


						$this->session->set_userdata('username', $data[0]->user_name);

						$data=array('token'=>$session);
						$result = $this->Auth_model->store_token($data, $userid, $password);

						
						$this->session->sess_expiration = '604800';// expires in 2 days
						$this->session->sess_expire_on_close = 'false';
						//$this->session->set_userdata($session);
						$this->session->set_userdata('token', $session);
						
						//redirect('ebay', 'refresh');
						redirect('Dashboard', 'refresh');
						
					}
				}

			}
		
		
			$this->load->view('auth/index',$data);
	}

	public function do_logout()
	{
		$this->session->sess_destroy();
		header('location:'.base_url());
	}



	public function sign_up()
	{

            $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
			$this->form_validation->set_rules('username', 'Username', 'required');
			$this->form_validation->set_rules('fname', 'First name', 'required');
			$this->form_validation->set_rules('fname', 'Last name', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required|min_length[5]');
            $this->form_validation->set_rules('password', 'Confirm Password', 'required|min_length[5]|matches[password]');
            $this->form_validation->set_rules('country', 'Country', 'required');


            if ($this->form_validation->run() == TRUE)
            {

            	$this->load->model("Auth_model");
				$res=$this->Auth_model->is_user_available($this->input->post('email'));

				if($res > 0)
				{
					$this->session->set_flashdata('message', 'User already Registered. Try another UserID...');
					redirect('auth/sign_up');
				}
            	else
            	{	
     //        		$salt = openssl_random_pseudo_bytes(32, $cstrong);

     //        		$options = [
					//   'cost' => 11,
					//   'salt' =>$salt 
					// ];

    				$hashed_password   = password_hash($this->input->post('cnfpassword'), PASSWORD_BCRYPT);
    				//print_r($hashed_password);


            		$data = array(
					'user_id' => $this->input->post('email'),
					'user_name' => $this->input->post('username'),
					'first_name' => $this->input->post('fname'),
					'last_name' => $this->input->post('lname'),
					'country' => $this->input->post('country'),
					'hashed_password' => $hashed_password,
					'token' => ''
					);

					if ($this->Auth_model->sign_up($data)) {

						$this->session->set_flashdata('message', 'Your Account Created Successfully');
						header('location:'.base_url());
					}

            	}
            	
            }

		$this->load->view('auth/sign_up');
	}

	// function _notMatch($password, $cnfpassword){
 //   		if($password != $this->input->post($cnfpassword)){
 //       		$this->form_validation->set_message('_notMatch', 'Password Mismatch with Confirm Password...');
 //      		return false;
 //   		}
 //  		return true;
	// }


	public function forgot()
	{
		// Redirect to your logged in landing page here

		$data['success'] = false;
		 
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|callback_email_exists');
		
		if($this->form_validation->run()){
			$email = $this->input->post('email');
			$this->load->model('Auth_model');
			if ($this->Auth_model->is_user_available($email)) {

				$slug = md5($email . date('Ymd'));
				$ci = get_instance();
				$ci->load->library('email');
				$config['protocol'] = "smtp";
				$config['smtp_host'] = "ssl://smtp.gmail.com";
				$config['smtp_port'] = "465";
				$config['smtp_user'] = "d1lgiq87@gmail.com"; 
				$config['smtp_pass'] = "Ogromniq87";
				$config['charset'] = "utf-8";
				$config['mailtype'] = "html";
				$config['newline'] = "\r\n";

				$ci->email->initialize($config);

				$ci->email->from('d1lgiq87@gmail.com', 'Blabla');
				$list = array($email);
				$ci->email->to($list);
				$this->email->reply_to('my-email@gmail.com', 'Explendid Videos');
				$ci->email->subject('This is an email test');
				$ci->email->message('To reset your password please click the link below and follow the instructions:
	      
				'. 'http://profitscraper.localhost/index.php/auth/reset/'.$slug .'/'.urlencode($email).'
				If you did not request to reset your password then please just ignore this email and no changes will occur.
				Note: This reset code will expire after '. date('j M Y'));
				$ci->email->send();
				
				
				$data['success'] = true;
			}
			
			
		}
		
		$this->load->view('auth/forgot_password', $data);
	}

	public function reset()
	{
		
		
		 //print_r($this->uri->segment(3));
		
		$this->load->helper('form');
		$data['success'] = false;
		 
		$email = $this->uri->segment(4);
		//print_r($email);
		//if(!$user_id) show_error('Invalid reset code.');
		$hash = $this->uri->segment(3);
		//print_r($hash);
		if(!$hash) show_error('Invalid reset code.a');
		
		$this->load->model('Auth_model');
			
		if($this->Auth_model->is_user_available(urldecode($email)) != 1) show_error('Invalid reset code.b');
		$slug = md5(urldecode($email) . date('Ymd'));
		if($hash != $slug) show_error('Invalid reset code.c');
	 
		$this->form_validation->set_rules('password', 'Password', 'required|min_length[5]');
		$this->form_validation->set_rules('password_conf', 'Confirm Password', 'required|matches[password]');
		
		if($this->form_validation->run()){
			$salt = openssl_random_pseudo_bytes(32, $cstrong);

			$options = [
			  'cost' => 11,
			  'salt' =>$salt 
			];

    		$hashed_password   = password_hash($this->input->post('password_conf'), PASSWORD_BCRYPT, $options);
			$result = $this->Auth_model->reset_password(urldecode($email), $hashed_password);
			//print_r($pr);
			if ($result) {
				$data['success'] = true;
			}else{
				show_error('error occured');
			}
			
		}
		
		$this->load->view('auth/reset_password', $data);
	}

	public function email_exists($email)
	{
		$this->load->model('Auth_model');
		 
		if($this->Auth_model->is_user_available($email)){
			return true;
		} else {
			$this->form_validation->set_message('email_exists', 'We couldn\'t find that email address in our system.');
			return false;
		}
	}
}

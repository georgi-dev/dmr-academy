<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SuperAdmin extends CI_Controller {

public function __construct()
{

	parent:: __construct();

	$this->load->database();

	$this->load->library('pagination');	
	$this->load->library('session');
	$this->load->library('form_validation');
	$this->load->helper('url');

	$this->load->model('Superadmin_model');
	
	
}
public function login()
{
	$data = array('message'=>'');
	$result="";
	if(isset($_POST['superlogin']))
	{

		$this->form_validation->set_rules('userid', 'User', 'required');

		$this->form_validation->set_rules('password', 'Password', 'required');

		$this->form_validation->set_error_delimiters('<div class="alert alert-danger">', '</div>');
		if($this->form_validation->run()==TRUE)
		{
			$userid = $this->input->post('userid');
			$password = $this->input->post('password');
			
			$this->load->model("Superadmin_login_model");
			$result=$this->Superadmin_login_model->login_do($userid,$password);
			if($result!=false)
			{
				$session = md5($userid.mt_rand(0,10000));

				//$_SESSION['token']=$session;

				$data=array('token'=>$session);
				$result = $this->Superadmin_login_model->store_token($data, $userid, $password);

				
				$this->session->sess_expiration = '604800';// expires in 2 days
				$this->session->sess_expire_on_close = 'false';
				//$this->session->set_userdata($session);
				$this->session->set_userdata('admintoken', $session);
				
				//redirect('ebay', 'refresh');
				redirect('SuperAdmin', 'refresh');
				
			}
			else
			{
				$data = array(
				    'message' => '<div class="alert alert-danger">Invalid Userid OR Password...!</div>'
				);
			}
		}

	}
	$this->load->view('super_admin/login/index',$data);
}

public function logout()
{
	$this->session->sess_destroy();
	header('location:'.base_url().'index.php/SuperAdmin/login');
}
public function index($pg=1)
{
	$token = $this->session->userdata('admintoken');

	if($token=="" || $token==null)
	{
		header('location:'.base_url().'index.php/SuperAdmin/login');
	}
	else
	{
		

		$recordcount = $this->Superadmin_model->get_count();

		$config["base_url"] = base_url()."index.php/SuperAdmin/index";
		$per_page=10;
		$config["total_rows"] = $recordcount;
		$config["per_page"] = $per_page;
		$config['use_page_numbers'] = TRUE;
		$config['num_links'] = $recordcount;
		$config['cur_tag_open'] = '&nbsp;<a class="current">';
		$config['cur_tag_close'] = '</a>';
		$config['next_link'] = 'Next';
		$config['prev_link'] = 'Previous';


		$this->pagination->initialize($config);
		if($this->uri->segment(3)){
			$page = ($this->uri->segment(3)) ;
		}
		else{
			$page = 1;
		}
		if($pg!=1)
			$pg=($pg-1)*$per_page;
		else
			$pg=0;


		$pg=$page-1;
		$count=$per_page;
		$start=$count*$pg;
		$paginate="";
		$privious="";
		$next="";


		$records= $recordcount;
	    $i=$page-2;
	    if($i<=0)
	        $i=1;
	    $end=$records/$count;



	    for(; $i>0 && $i<$page ; $i++)
	    {
	        $privious="<li class='page-item'><a class='page-link' href='".base_url()."index.php/SuperAdmin/index/$i'>Previous</a></li>";

	        $paginate.="<li class='page-item'><a class='page-link' href='".base_url()."index.php/SuperAdmin/index/$i'>$i</a></li>";
	    }
	    if($page==0)
	        $page=1;
	    $paginate.="<li class='page-item active'><span class='page-link'>$page</span></li>";
	    $i=$i+1;


	    $isnext=0;
	    for(; $i<=$end && $i<$page+3 ; $i++)
	    {
	        if($isnext==0)
	        {
	            $next="<li class='page-item'><a class='page-link' href='".base_url()."index.php/SuperAdmin/index/$i'>Next</a></li>";
	            $isnext=1;
	        }
	        $paginate.="<li class='page-item'><a class='page-link' href='".base_url()."index.php/SuperAdmin/index/$i'>$i</a></li>";

	    }

	    if(($i-1)<$end)
	    {
	        $paginate.="<li class='page-item'><a class='page-link' href='".base_url()."index.php/SuperAdmin/index/$i'>$i</a></li>";
	        if($isnext==0)
	        {
	            $next="<li class='page-item'><a class='page-link' href='".base_url()."index.php/SuperAdmin/index/$i'>Next</a></li>";
	            $isnext=1;
	        }

	    }


		$res = $this->Superadmin_model->get_all_schedule($config["per_page"], $start);
		$links =$privious.$paginate.$next;// $this->pagination->create_links();
		//$data['data'] = $res;
		$links = $this->pagination->create_links();
		$data = array('data'=>$res, 'links'=>$links);

		$this->load->view('super_admin/schedule/index',$data);	
	}
	
}


public function userlist($pg=1)
{


	$recordcount = $this->Superadmin_model->get_user_cnt();

	$config["base_url"] = base_url()."index.php/SuperAdmin/userlist";
	$per_page=10;
	$config["total_rows"] = $recordcount;
	$config["per_page"] = $per_page;
	$config['use_page_numbers'] = TRUE;
	$config['num_links'] = $recordcount;
	$config['cur_tag_open'] = '&nbsp;<a class="current">';
	$config['cur_tag_close'] = '</a>';
	$config['next_link'] = 'Next';
	$config['prev_link'] = 'Previous';

	$this->pagination->initialize($config);
	if($this->uri->segment(3)){
		$page = ($this->uri->segment(3)) ;
	}
	else{
		$page = 1;
	}
	if($pg!=1)
		$pg=($pg-1)*$per_page;
	else
		$pg=0;

	//chirag code
	
	$pg=$page-1;
	$count=$per_page;
	$start=$count*$pg;
	$paginate="";
	$privious="";
	$next="";


	$records= $recordcount;
    $i=$page-2;
    if($i<=0)
        $i=1;
    $end=$records/$count;



    for(; $i>0 && $i<$page ; $i++)
    {
        $privious="<li class='page-item'><a class='page-link' href='".base_url()."index.php/SuperAdmin/userlist/$i'>Previous</a></li>";

        $paginate.="<li class='page-item'><a class='page-link' href='".base_url()."index.php/SuperAdmin/userlist/$i'>$i</a></li>";
    }
    if($page==0)
        $page=1;
    $paginate.="<li class='page-item active'><span class='page-link'>$page</span></li>";
    $i=$i+1;


    $isnext=0;
    for(; $i<=$end && $i<$page+3 ; $i++)
    {
        if($isnext==0)
        {
            $next="<li class='page-item'><a class='page-link' href='".base_url()."index.php/SuperAdmin/userlist/$i'>Next</a></li>";
            $isnext=1;
        }
        $paginate.="<li class='page-item'><a class='page-link' href='".base_url()."index.php/SuperAdmin/userlist/$i'>$i</a></li>";

    }

    if(($i-1)<$end)
    {
        $paginate.="<li class='page-item'><a class='page-link' href='".base_url()."index.php/SuperAdmin/userlist/$i'>$i</a></li>";
        if($isnext==0)
        {
            $next="<li class='page-item'><a class='page-link' href='".base_url()."index.php/SuperAdmin/userlist/$i'>Next</a></li>";
            $isnext=1;
        }

    }

	//


	//$res = $this->Superadmin_model->get_user($config["per_page"],$start);
	$res_sche = $this->Superadmin_model->get_user_schedule($config["per_page"],$start);
	$res_pro = $this->Superadmin_model->get_user_product($config["per_page"],$start);
	$output = array();
	$cnt = count($res_sche->result_array());
	if($cnt > 0)
	{
		
		$result = array();
		$res = $res_sche->result_array();
		$res2 = $res_pro->result_array();
		for($i=0; $i<$cnt; $i++)
		{
			$result['id'] = $res[$i]['id'];
			$result['user_name'] = $res[$i]['user_name'];
			$result['user_email'] = $res[$i]['user_email'];
			$result['sche_cnt'] = $res[$i]['sche_cnt'];
			$result['is_active'] = $res[$i]['is_active'];
			$result['pro_cnt'] = $res2[$i]['pro_cnt'];
			array_push($output, $result);
		}
	}

	//$res = $this->Superadmin_model->get_user();
	$links =$privious.$paginate.$next;// $this->pagination->create_links();

	if(count($output) > 0)
		$data = array('data'=>$output, 'links'=>$links);
	else
		$data = array('data'=>false, 'links'=>false);


	$this->load->view('super_admin/users/index',$data);	

}


public function adduser()
{
	
	if(isset($_POST['adduser']))
	{
		
		$this->form_validation->set_rules('username', 'User Name', 'required|callback_isString');
		$this->form_validation->set_rules('useremail', 'User Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required');
        $this->form_validation->set_rules('cnfpassword', 'Confirm Password', 'required|callback__notMatch[password]');

        if ($this->form_validation->run() == TRUE)
        {

        	$this->load->model("login_model");
			$res=$this->login_model->is_user_available($this->input->post('useremail'));

			if($res > 0)
			{
				$this->session->set_flashdata('message', 'User allredy Registered. Try another User Email...');
				//redirect('login/create_account');
				redirect('Super_admin/add_user');
			}
        	else
        	{
        		$rec = array(
    			'user_name' => $this->input->post('username'),
				'user_id' => $this->input->post('useremail'),
				'password' => $this->input->post('cnfpassword'),
				'token' => '',
				'is_user_active' => 1
				);

				$this->db->insert('users', $rec);
				$this->session->set_flashdata('message', 'Your Accont Created Successfully');
				redirect('SuperAdmin/userlist');
				//header('location:http://crawler360.com/ebayscraper_new');
				//header('location:http://localhost/Ebay_scraper');	
        	}
        	
        }

	}
	$this->load->view('super_admin/users/add_user');
}


public function prolist($pg=1)
{
	$sche_id = $this->uri->segment(3);
	//echo $sche_id; die();
	$this->load->model("setting_model");
	$this->load->model("screen_message_model");

	$state = $this->setting_model->get_state();
	$state = $state->result()[0]->state;

	$recordcount = $this->Superadmin_model->get_cnt($sche_id);
	
	$msginfo = array('seller'=>'', 'keyword'=>'', 'item'=>'', 'pageresult'=>'', 'search_link'=>'', 'searchfrom'=>'', 'scrapeditem'=>'');
	$msginfo['scrapeditem'] = $recordcount;

	//$scrmsg = $this->screen_message_model->get_message();
	$scrmsg = $this->screen_message_model->get_message($sche_id);
	$msginfo['seller'] = $scrmsg->result()[0]->seller_name;
	$msginfo['keyword'] = $scrmsg->result()[0]->keyword;
	$msginfo['item'] = $scrmsg->result()[0]->item;
	$msginfo['pageresult'] = $scrmsg->result()[0]->scraped_result;
	$msginfo['search_link'] = $scrmsg->result()[0]->search_link;
	$msginfo['searchfrom'] = $scrmsg->result()[0]->search_from;

	$config["base_url"] = base_url()."index.php/SuperAdmin/prolist/".$sche_id;
	$per_page=10;
	$config["total_rows"] = $recordcount;
	$config["per_page"] = $per_page;
	$config['use_page_numbers'] = TRUE;
	$config['num_links'] = $recordcount;
	$config['cur_tag_open'] = '&nbsp;<a class="current">';
	$config['cur_tag_close'] = '</a>';
	$config['next_link'] = 'Next';
	$config['prev_link'] = 'Previous';


	$this->pagination->initialize($config);
	if($this->uri->segment(4)){
		$page = ($this->uri->segment(4)) ;
	}
	else{
		$page = 1;
	}

	if($page!=1)
		$pg=($page-1)*10;
	else
		$pg=0;

	$pg=$page-1;
	$count=$per_page;
	$start=$count*$pg;
	$paginate="";
	$privious="";
	$next="";


	$records= $recordcount;
    $i=$page-2;
    if($i<=0)
        $i=1;
    $end=$records/$count;



    for(; $i>0 && $i<$page ; $i++)
    {
        $privious="<li class='page-item'><a class='page-link' href='".base_url()."index.php/SuperAdmin/prolist/$sche_id/$i'>Previous</a></li>";

        $paginate.="<li class='page-item'><a class='page-link' href='".base_url()."index.php/SuperAdmin/prolist/$sche_id/$i'>$i</a></li>";
    }
    if($page==0)
        $page=1;
    $paginate.="<li class='page-item active'><span class='page-link'>$page</span></li>";
    $i=$i+1;


    $isnext=0;
    for(; $i<=$end && $i<$page+3 ; $i++)
    {
        if($isnext==0)
        {
            $next="<li class='page-item'><a class='page-link' href='".base_url()."index.php/SuperAdmin/prolist/$sche_id/$i'>Next</a></li>";
            $isnext=1;
        }
        $paginate.="<li class='page-item'><a class='page-link' href='".base_url()."index.php/SuperAdmin/prolist/$sche_id/$i'>$i</a></li>";

    }

    if(($i-1)<$end)
    {
        $paginate.="<li class='page-item'><a class='page-link' href='".base_url()."index.php/SuperAdmin/prolist/$sche_id/$i'>$i</a></li>";
        if($isnext==0)
        {
            $next="<li class='page-item'><a class='page-link' href='".base_url()."index.php/SuperAdmin/prolist/$sche_id/$i'>Next</a></li>";
            $isnext=1;
        }

    }

	$res = $this->Superadmin_model->get_pro($sche_id, $config["per_page"], $start);
	$links =$privious.$paginate.$next;// $this->pagination->create_links();

	$data = array('data'=>$res, 'state'=>$state, 'msginfo'=>$msginfo, 'links'=>$links);
	$this->load->view('super_admin/schedule/view_pro',$data);

}



public function changeschedulestate()
{
	$usr_sche_id = $this->uri->segment(3);
	$res = $this->Superadmin_model->check_sche_state($usr_sche_id);

	if($res == 1)
	{
	
		$data=array('is_active'=>2);
		$this->db->where('user_sch_id', $usr_sche_id);
		$this->db->update('user_schedule',$data);
		redirect('SuperAdmin');
	}
	if($res == 2)
	{

		$data=array('is_active'=>1);
		$this->db->where('user_sch_id', $usr_sche_id);
		$this->db->update('user_schedule',$data);
		redirect('SuperAdmin');	
	}
}


public function changeuserstate()
{
	
	$user_id = $this->uri->segment(3);
	
	$res = $this->Superadmin_model->check_user_state($user_id);
	if($res == 1)
	{
		$data=array('is_user_active'=>2);
		$this->db->where('id', $user_id);
		$this->db->update('users',$data);
		redirect('SuperAdmin/userlist');
	}
	if($res == 2)
	{
		$data=array('is_user_active'=>1);
		$this->db->where('id', $user_id);
		$this->db->update('users',$data);
		redirect('SuperAdmin/userlist');	
	}
}


public function viewproduct($pg=1)
{

	$user_id = $this->uri->segment(3);

	$sche_id = array();
	$res = $this->Superadmin_model->get_schedule_id($user_id);
	$id = $res->result_array();
	$sche_cnt = $res->num_rows();

	for($i=0; $i<$sche_cnt; $i++)
	{
		array_push($sche_id, $id[$i]['schedule_id']);
	}
	
	$per_page = 2;
	$page = $this->uri->segment(4);

	
	

	$this->pagination->initialize($config);
	if($this->uri->segment(4)){
		$page = ($this->uri->segment(4)) ;
	}
	else{
		$page = 1;
	}

	if($page!=1)
		$pg=($page-1)*$config["per_page"];
	else
		$pg=0;

	$products = $this->Superadmin_model->get_all_pro($sche_id, $per_page, $pg);
	$links = $this->pagination->create_links();



	$data = array('products'=>$products->result(), 'pro_cnt'=>$recordcount, 'links'=>$links);

	$this->load->view('super_admin/users/view_pro',$data);

}



function _notMatch($password, $cnfpassword){
	if($password != $this->input->post($cnfpassword)){
		$this->form_validation->set_message('_notMatch', 'Password Mismatch with Confirm Password...');
		return false;
	}
	return true;
}


function isString($str){
	if(!ctype_alnum($str))
	{
		$this->form_validation->set_message('isString', 'The User Name field must contain only alpha numeric character');
        return FALSE;
	}
	else
	{
		return TRUE;
	}
}

}

?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Super_admin_login extends CI_Controller {

public function __construct()
{

	parent:: __construct();

	$this->load->database();

	$this->load->library('pagination');	

	$this->load->library('session');

	$this->load->library('form_validation');
	$this->load->helper('url');
	
}


public function index()
{
	$data = array('message'=>'');
	$result="";
	if(isset($_POST['superlogin']))
	{
		
		$this->form_validation->set_rules('userid', 'User', 'required');

		$this->form_validation->set_rules('password', 'Password', 'required');

		$this->form_validation->set_error_delimiters('<div class="alert alert-danger">', '</div>');
		if($this->form_validation->run()==TRUE)
		{
			$userid = $this->input->post('userid');
			$password = $this->input->post('password');
			
			$this->load->model("Superadmin_login_model");
			$result=$this->Superadmin_login_model->login_do($userid,$password);
			if($result!=false)
			{
				$session = md5($userid.mt_rand(0,10000));

				//$_SESSION['token']=$session;

				$data=array('token'=>$session);
				$result = $this->Superadmin_login_model->store_token($data, $userid, $password);

				
				$this->session->sess_expiration = '604800';// expires in 2 days
				$this->session->sess_expire_on_close = 'false';
				//$this->session->set_userdata($session);
				$this->session->set_userdata('admintoken', $session);
				
				//redirect('ebay', 'refresh');
				redirect('Super_admin', 'refresh');
				
			}

			if($result==false)
			{
				$data = array(
				    'message' => '<div class="alert alert-danger">Invalid Userid OR Password...!</div>'
				);
			}
		}

	}
	$this->load->view('super_admin/login/index',$data);
}


public function do_logout()
{
	$this->session->sess_destroy();
	header('location:'.base_url().'index.php/Super_admin_login');
}

}

?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()
	{

		parent:: __construct();

		$this->load->database();

		$this->load->library('pagination');	
		$this->load->library('session');
		$this->load->library('form_validation');
		$this->load->helper('url');
		$this->load->model('Profile_model');

	}

	public function index()
	{
		$this->load->view('profile/index');
	}

	public function edit()
	{
		
		//$this-load->view('profile/index');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
			$this->form_validation->set_rules('username', 'Username', 'required');
			$this->form_validation->set_rules('fname', 'First name', 'required');
			$this->form_validation->set_rules('fname', 'Last name', 'required');
            $this->form_validation->set_rules('country', 'Country', 'required');


            if ($this->form_validation->run() == TRUE)
            {

        		$data = array(
				'user_id' => $this->input->post('email'),
				'user_name' => $this->input->post('username'),
				'first_name' => $this->input->post('fname'),
				'last_name' => $this->input->post('lname'),
				'country' => $this->input->post('country')
				);

				if ($this->Profile_model->edit_profile($data)) {

					$this->session->unset_userdata('username');

					$this->session->set_userdata('username', $data['user_name']);
					$this->session->set_flashdata('message', 'Your profile was edited Successfully');
					header('location:'.base_url().'index.php/dashboard');
				}

            }
            	
            

		
		$this->load->view('profile/edit');
	}
}
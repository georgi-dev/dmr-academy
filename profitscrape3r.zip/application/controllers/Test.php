<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Test extends CI_Controller {
 
        /**
         * load list modal, library and helpers
         */
         function __Construct(){
           parent::__Construct();
           $this->load->helper(array('form', 'url'));
           //$this->load->model('test_model');
           //$this->load->library('mylibrary');
         }
          
        /**
         *  @desc : Function to perform multiple task in background
         *  @param :void
         *  @return : void
         */
         public  function index(){
 
              /* $stack = array();

              //Initiate Multiple Thread
              foreach ( range("A", "D") as $i ) {
                  $stack[] = new mylibrary($i);

              }

              // Start The Threads
              foreach ( $stack as $t ) {
                  $t->start();
}*/
      //phpinfo();

             
        }
         
        /**
         *  @desc : Function to send mail 
         *  @param :void
         *  @return : void
         */
        public function sendmail(){
 
            /*$this->load->library('email');
            $user_email  = $_POST['email'];
            $message     = "Testing";
          
            $this->email->from('heyrajcool@gmail.com', 'Around');
            $this->email->to($user_email); 
            $this->email->subject("test");
            $this->email->message($message);  
            $this->email->send();*/
        }
         
         /**
         *  @desc : Function to call insert() method 
         *  of test_model to insert data in database
         *  @param :void
         *  @return : void
         */
       public function insert(){
 
           /*$email = $this->input->post('email');
           $name = $this->input->post('name');
           $this->test_model->insert($email, $name);*/
      }
}

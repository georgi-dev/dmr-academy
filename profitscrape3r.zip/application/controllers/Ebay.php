<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ebay extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()

	{

		parent:: __construct();

		$this->load->database();

		$this->load->library('pagination');	

		$this->load->library('session');

		$this->load->library('form_validation');
		$this->load->helper('url');
		
	}
	
	public function index($pg=1)
	{
		
			
	}
	public function cronjob_exists($command)
	{

	    $cronjob_exists=false;

	    /*exec('crontab -l', $crontab);


	    if(isset($crontab)&&is_array($crontab)){

	        $crontab = array_flip($crontab);

	        if(isset($crontab[$command])){

	            $cronjob_exists=true;

	        }

	    }*/
	    return $cronjob_exists;
	}

	public function append_cronjob($command)
	{

	    /*if(is_string($command) && !empty($command) && $this->cronjob_exists($command)===FALSE){

	        //add job to crontab
	        exec('echo -e "`crontab -l`\n'.$command.'" | crontab -', $output);


	    }*/

	    return $output;
	}

	public function stop_execution()
	{

		$this->load->model("setting_model");
		$this->setting_model->stop_script();
		die();
	}
	public function check_page()
	{
		/*$this->load->model("screen_message_model");
		$scrmsg = $this->screen_message_model->get_message();
		$link=$scrmsg->result()[0]->search_link;*/
		//echo $this->get_page("http://www.ebay.co.uk/sch/m.html?_nkw=&_armrs=1&_from=&_ssn=mutha_funksta&_ipg=200&rt=nc");
	}
	public function executelink_cron1($UserId, $schedule_id)
	{	

		if(!$this->input->is_cli_request())
		{
			echo "There is no server request";
			exit();
		}

		$this->load->model("schedule_model");
		$schedule = $this->schedule_model->get_schedule_by_id($schedule_id);
		
		if(empty($schedule))
		{
			echo "done die";
			die();
		}
		$id = $schedule->seller_name;
		$keyword = $schedule->keyword;
		$item = $schedule->item;
		$searchfrom = $schedule->search_from;
		$url="";
		$sch_id=$schedule_id;

		if($schedule->search_from!="")
			$searchfrom=urlencode($schedule->search_from);
		if($schedule->seller_name!="")
			$id = urlencode($schedule->seller_name);
		if($schedule->keyword!="")
			$keyword = "&_nkw=".urlencode($schedule->keyword);
		if($schedule->item!="")
			$item = $schedule->item;

		if($keyword=="" && $id!="")
		{
			$id=$schedule->seller_name;
			if($item=='Sold Items')
			{

				if($searchfrom=="USA")
					$url="http://www.ebay.com/sch/".$id."/m.html?_nkw&_armrs=1&_from&_ipg=200&LH_Complete=1&LH_Sold=1&rt=nc&_trksid=p2046732.m1684";
				if($searchfrom=="UK")
					$url="http://www.ebay.co.uk/sch/".$id."/m.html?_nkw&_armrs=1&_from&_ipg=200&LH_Complete=1&LH_Sold=1&rt=nc&_trksid=p2046732.m1684";
				
			}
			else
			{
				if($searchfrom=="USA")
					$url="http://www.ebay.com/sch/m.html?_nkw=&_armrs=1&_from=&_ipg=200&_ssn=".$id;
				if($searchfrom=="UK")
					$url="http://www.ebay.co.uk/sch/m.html?_nkw=&_armrs=1&_from=&_ssn=".$id."&_ipg=200&rt=nc";
				
			}
		}
		else
		{
			if($item=='Sold Items')
			{
				if($searchfrom=='USA')
					$searchtype="&LH_Sold=1";
				if($searchfrom=='UK')
					$searchtype="&LH_Sold=1";
			}
			else{
				$searchtype="";
			}
			if($searchfrom=="USA")
				$url="http://www.ebay.com/sch/".$id."/m.html?".$keyword."&_ipg=200&_armrs=1&_ipg=&_from=".$searchtype; //'http://www.ebay.co.uk/sch/i.html?_from=R40&_sacat=0'.$keyword.'&rt=nc&_clu=2&_fcid=95&_ipg=200&_stpos=361%20001&gbr=1'.$id.$searchtype;;
			if($searchfrom=="UK")
				$url = 'http://www.ebay.co.uk/sch/m.html?_from=R40&_sacat=0'.$keyword.'&rt=nc&_clu=2&_fcid=95&_ipg=200&gbr=1&_ssn='.$id.$searchtype;
			
		}

		$msginfo = array();
		
		$msginfo['sallerid'] = $id;
		$msginfo['keyword'] = $keyword;
		$msginfo['item'] = $item;
		$msginfo['searchfrom'] = $searchfrom;
		$this->load->model("screen_message_model");		
		$res = $this->screen_message_model->update_screen($msginfo);
		
		//links scraping
		$page=$url;
		$scrapedlink=1;
		$msginfo = array();
		$msginfo['search_link'] = $this->db->escape($page);
		
		$this->load->model("screen_message_model");		
		$res = $this->screen_message_model->update_screen($msginfo);

		$this->load->model("schedule_model");		
		$res = $this->schedule_model->pending($schedule_id);
		$res = $this->schedule_model->updatesearchlink($page,$schedule_id);
		while($page!="")
		{
			$pageurl = array();
			$c=0;
			$link_details = $this->get_page($page);

			libxml_use_internal_errors(true);
			$domhtml = new DOMDocument();
			$domhtml->loadHTML($link_details);
			$xpathdata = new DOMXPath($domhtml);
			$rec="--";
			if($xpathdata->query("//div[3]/span"))
			{
				$value = $xpathdata->query("//div[3]/span");
				$rec=$value->item(0)->nodeValue;
			}
			if($xpathdata->query("//span[@class='rcnt']"))
			{
				$value = $xpathdata->query("//span[@class='rcnt']");
				$rec=$value->item(0)->nodeValue;
			}

			if($rec=="")
			{
				$msginfo['pageresult']="";
				$res = $this->screen_message_model->update_screen($msginfo);
			}
			else
			{
				$msginfo['pageresult']=$this->db->escape($rec);
				$res = $this->screen_message_model->update_screen($msginfo);
			}

			$product_blocks=$xpathdata->query('//ul[@id="ListViewInner"]/li');
			$links_page=array();
			foreach($product_blocks as $product_block)
			{
				$data=array();
				$product_part=$this->DOMinnerHTML($product_block);
				$domhtml = new DOMDocument();
				@$domhtml->loadHTML($product_part);
				$xpathdata1 = new DOMXPath($domhtml);
				$page_lk=$xpathdata1->query('//h3/a/@href')->item(0)->nodeValue;
				$page_lk=explode("?", $page_lk)[0];
				if($page_lk=="")
					continue;
				$data["pageurl"]=$page_lk;
				$links_page[]=$page_lk;
				$scrapedlink=$scrapedlink+1;
				if($xpathdata1->query("//li[@class='timeleft']/span/span"))
				{
					$value = $xpathdata1->query("//li[@class='timeleft']/span/span");
					if($value->item(0))
					{
						$data["sold"]=$value->item(0)->nodeValue;
						
					}
					else
					{
						$data["sold"]="";
					}
				}
				else
				{
					$data["sold"]="";
				}
				$data["schedule_id"]=$schedule_id;
				
				$this->load->model("ebay_link_model");
				$count=$this->ebay_link_model->add_url($data);
				$pageurl[$c]=$data;//$node->nodeValue;
				$c++;
			}
			$res = $this->schedule_model->active($schedule_id);
			
			//$this->scrape_page($pageurl);
			$page="";
			if($xpathdata->query("//a[@class='gspr next']/@href"))
			{
				$value = $xpathdata->query("//a[@class='gspr next']/@href");
				if($value->item(0))
				{
					$page=$value->item(0)->nodeValue;
				}
				else
				{
					$page="";
				}
				
			}

				
		}
		$res = $this->schedule_model->active($schedule_id);
		$this->load->model('Scraper_model');
		$this->Scraper_model->finishScraper($UserId);
	    
	}
	

	public function add_cron()
	{
		/*exec('crontab -r');
		//$state = $this->setting_model->stop_script();
		$this->append_cronjob('* * * * * curl -s http://crawler360.com/ebay_version2/index.php/Products/pro_detail_Scraper_script1');
		$this->append_cronjob('* * * * * curl -s http://crawler360.com/ebay_version2/index.php/Products/pro_detail_Scraper_script2');
		$this->append_cronjob('* * * * * curl -s http://crawler360.com/ebay_version2/index.php/Products/pro_detail_Scraper_script3');
		$this->append_cronjob('* * * * * curl -s http://crawler360.com/ebay_version2/index.php/Products/pro_detail_Scraper_script4');
		$this->append_cronjob('* * * * * curl -s http://crawler360.com/ebay_version2/index.php/Ebay/executelink_cron1');
		$this->append_cronjob('* * * * * curl -s http://crawler360.com/ebay_version2/index.php/Ebay/executelink_cron2');

		echo "cron Running";*/
	}

	/*public function add_cron()
	{
		exec('crontab -r');
		//$state = $this->setting_model->stop_script();
		$this->append_cronjob('* * * * * curl -s http://localhost/Ebay_scraper_new/index.php/Products/pro_detail_Scraper_script1');
		$this->append_cronjob('* * * * * curl -s http://localhost/Ebay_scraper_new/index.php/Products/pro_detail_Scraper_script2');
		$this->append_cronjob('* * * * * curl -s http://localhost/Ebay_scraper_new/index.php/Products/pro_detail_Scraper_script3');
		$this->append_cronjob('* * * * * curl -s http://localhost/Ebay_scraper_new/index.php/Products/pro_detail_Scraper_script4');
		$this->append_cronjob('* * * * * curl -s http://localhost/Ebay_scraper_new/index.php/Ebay/executelink_cron1');
		$this->append_cronjob('* * * * * curl -s http://localhost/Ebay_scraper_new/index.php/Ebay/executelink_cron2');

		echo "cron Running";
	}*/
	public 	function get_page($url)
	{
		
		$options = Array(
			CURLOPT_RETURNTRANSFER => true,  // Setting cURL's option to return the webpage data
			CURLOPT_FOLLOWLOCATION => true,  // Setting cURL to follow 'location' HTTP headers
			CURLOPT_AUTOREFERER => true, // Automatically set the referer where following 'location' HTTP headers
			CURLOPT_CONNECTTIMEOUT => 300,   // Setting the amount of time (in seconds) before the request times out
			CURLOPT_TIMEOUT => 300,  // Setting the maximum amount of time for cURL to execute queries
			CURLOPT_MAXREDIRS => 10, // Setting the maximum number of redirections to follow
			CURLOPT_USERAGENT => "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0",  // Setting the useragent
			CURLOPT_URL => $url,
			//CURLOPT_PROXY=>"de.proxymesh.com:31280",
			//CURLOPT_PROXYTYPE => CURLPROXY_HTTP,
			
			 // Setting cURL's URL option with the $url variable passed into the function
			
		);

		$ch = curl_init();  // Initialising cURL
		curl_setopt_array($ch, $options);   // Setting cURL's options using the previously assigned array data in $options
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
	    'X-Apple-Tz: 0',
	    'X-Apple-Store-Front: 143444,12'
	    ));
		//curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		$data = curl_exec($ch); // Executing the cURL request and assigning the returned data to the $data variable
		if(curl_exec($ch) === false)
		{
		    echo 'Curl error: ' . curl_error($ch);
		}
		curl_close($ch);    // Closing cURL
		return $data;   // Returning the data from the function

	}


	function DOMinnerHTML(DOMNode $element) 
	{ 
	    $innerHTML = ""; 
	    $children  = $element->childNodes;

	    foreach ($children as $child) 
	    { 
	        $innerHTML .= $element->ownerDocument->saveHTML($child);
	    }

	    return $innerHTML; 
	} 

	//link scraper
	//pro_detail_Scraper
	public function check()
	{
		echo date("Y-m-d H:i:s")."<br>";
		echo date("Y-m-d H:i:s", strtotime('-1 minute'));//1430
		$this->load->model("ebay_link_model");
		$result= $this->ebay_link_model->get_count();
		echo "<br>";

		echo sizeof($result);
		echo "<br>";
		$finddate = date("Y-m-d H:i:s", strtotime('-1 minute'));//1430

		$this->load->model("schedule_model");
		$schedule = $this->schedule_model->cron_get_schedule($finddate);
		print_r($schedule);
	}
	
	
	
	function remove_sym($snip)
	{
		$snip = str_replace('Â£', '£', $snip); // Â
		$snip = str_replace('\t', '', $snip); // remove tabs
		$snip = str_replace('\n', '', $snip); // remove new lines
		$snip = str_replace('\r', '', $snip); // remove carriage returns
		return $snip;
	}

	
	
}

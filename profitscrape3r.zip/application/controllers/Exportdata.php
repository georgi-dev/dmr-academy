<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Exportdata extends CI_Controller {

public function __construct()
{

	parent:: __construct();

	$this->load->database();

	$this->load->library('pagination');	

	$this->load->library('session');

	$this->load->library('form_validation');
	$this->load->helper('url');
	
}

public function index()
{
	$this->load->model('export_model');
	$this->export_model->export_ebay_data();
}

}

?>
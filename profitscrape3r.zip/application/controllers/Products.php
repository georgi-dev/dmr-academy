<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct()

	{

		parent:: __construct();

		$this->load->database();

		$this->load->library('pagination');	

		$this->load->library('session');

		$this->load->library('form_validation');
		$this->load->helper('url');
		
	}
	function remove_sym($snip)
	{
		$snip = str_replace('Â£', '£', $snip); // Â
		$snip = str_replace('Â', '', $snip);
		$snip = str_replace('\t', '', $snip); // remove tabs
		$snip = str_replace('\n', '', $snip); // remove new lines
		$snip = str_replace('\r', '', $snip); // remove carriage returns
		return $snip;
	}
	public function cronjob_exists($command)
	{

	    $cronjob_exists=false;

	    /*exec('crontab -l', $crontab);


	    if(isset($crontab)&&is_array($crontab)){

	        $crontab = array_flip($crontab);

	        if(isset($crontab[$command])){

	            $cronjob_exists=true;

	        }

	    }*/
	    return $cronjob_exists;
	}

	public function append_cronjob($command)
	{

	   /* if(is_string($command) && !empty($command) && $this->cronjob_exists($command)===FALSE){

	        //add job to crontab
	        exec('echo -e "`crontab -l`\n'.$command.'" | crontab -', $output);


	    }*/

	    return $output;
	}

	function DOMinnerHTML(DOMNode $element) 
	{ 
	    $innerHTML = ""; 
	    $children  = $element->childNodes;

	    foreach ($children as $child) 
	    { 
	        $innerHTML .= $element->ownerDocument->saveHTML($child);
	    }

	    return $innerHTML; 
	}

	function get_product_details()
	{	
		if(!$this->input->is_cli_request())
		{
			echo "There is no server request";
			exit();
		}

		set_time_limit(0);
		$linkscrape = 0;
		while (true)
		{
			if ($linkscrape >= 20) die();
			$linkscrape = $linkscrape + 1;
			$this->load->model("ebay_link_model");
			$ebay_rec = $this->ebay_link_model->get_link();
			if (empty($ebay_rec))
			{
				die();
			}

			$sold = $ebay_rec["sold"];
			$url = $ebay_rec["url"];
			$this->load->model("ebay_model");
			$data = array();

			// $link_details = $this->get_page4($url);
			$proxy = "207.182.156.11:80";
			$options = Array(
				CURLOPT_RETURNTRANSFER => true, // Setting cURL's option to return the webpage data
				CURLOPT_FOLLOWLOCATION => true, // Setting cURL to follow 'location' HTTP headers
				CURLOPT_AUTOREFERER => true, // Automatically set the referer where following 'location' HTTP headers
				CURLOPT_CONNECTTIMEOUT => 300, // Setting the amount of time (in seconds) before the request times out
				CURLOPT_TIMEOUT => 300, // Setting the maximum amount of time for cURL to execute queries
				CURLOPT_MAXREDIRS => 10, // Setting the maximum number of redirections to follow
				CURLOPT_USERAGENT => "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0", // Setting the useragent
				CURLOPT_URL => $url,
			);
			$ch = curl_init(); // Initialising cURL
			curl_setopt_array($ch, $options); // Setting cURL's options using the previously assigned array data in $options
			curl_setopt($ch, CURLOPT_POST, true);
			//curl_setopt($ch, CURLOPT_PROXY, $proxy);
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array(
				'X-Apple-Tz: 0',
				'X-Apple-Store-Front: 143444,12'
			));
			$link_details = curl_exec($ch); // Executing the cURL request and assigning the returned data to the
			curl_close($ch); // Closing cURL

			// Retur

			libxml_use_internal_errors(true);
			$domhtml = new DOMDocument();
			$domhtml->loadHTML($link_details);
			$xpathdata = new DOMXPath($domhtml);
			$data['price'] = "";
			$data['title'] = "";
			if ($xpathdata->query("//h1[@id='itemTitle']"))
			{
				$value = $xpathdata->query("//h1[@id='itemTitle']");
				if ($value) $data['title'] = trim(str_replace("Details about","",str_replace("&nbsp;"," ",$value->item(0)->nodeValue)));
			}

			if ($data['title'] != "")
			{
				if ($xpathdata->query("//span[contains(@id,'prcIsum')]"))
				{
					$value = $xpathdata->query("//span[contains(@id,'prcIsum')]");
					if ($value) $data['price'] = trim($value->item(0)->nodeValue);
				}

				if ($xpathdata->query("//span[@id='mm-saleDscPrc']") && $data["price"] == "")
				{
					$value = $xpathdata->query("//span[@id='mm-saleDscPrc']");
					if ($value) $data['price'] = trim($value->item(0)->nodeValue);
				}

				if ($xpathdata->query("//span[@class='notranslate']") && $data["price"] == "")
				{
					$value = $xpathdata->query("//span[@class='notranslate']");
					if ($value) $data['price'] = trim($value->item(0)->nodeValue);
				}

				if ($xpathdata->query("//span[@class='notranslate vi-VR-cvipPrice']") && $data["price"] == "")
				{
					$value = $xpathdata->query("//span[@class='notranslate vi-VR-cvipPrice']");
					if ($value) $data['price'] = trim($value->item(0)->nodeValue);
				}

				if ($xpathdata->query("//a[contains(text(),' sold')]/parent::span"))
				{
					$value = $xpathdata->query("//a[contains(text(),' sold')]/parent::span");
					if ($value) $data['sold_count'] = trim($value->item(0)->nodeValue);
				}

				if ($xpathdata->query("//span[@id='vi-bybox-watchers']"))
				{
					$value = $xpathdata->query("//span[@id='vi-bybox-watchers']");
					if ($value)
					{
						$explodeval = $value->item(0)->nodeValue;
						$watchers = explode(" ", $explodeval);
						$data['watchers'] = trim($watchers[0]);
					}
				}

				if ($xpathdata->query("//a[@id='mbgLink']"))
				{
					$value = $xpathdata->query("//a[@id='mbgLink']");
					if ($value) $data['seller'] = trim($value->item(0)->nodeValue);
				}
				//*[@id="RightSummaryPanel"]/div[3]/div/div/div[2]
//$xpathdata->query("//*[@id=\"RightSummaryPanel\"]/div[3]/div/div/div[2]/a[contains(text(),' Top-rated seller ')]");
/*				if ($xpathdata->query("//*[@id=\"RightSummaryPanel\"]/div[3]/div/div/div[2]/h2/a[contains(text(),' Top-rated seller ')]")) {
					$value = $xpathdata->query("//*[@id=\"RightSummaryPanel\"]/div[3]//h2/a[contains(@href,'topratedsellers')]");
					print_r($value->item(0)->nodeValue);
					if ($value->item(0)->nodeValue)
					{
						$explodeval = $value->item(0)->nodeValue;
						if ($explodeval) $data['is_seller_top'] = "yes";
						else $data['is_seller_top'] = "no";
					}else{
						echo "WHY?";
						$data['is_seller_top'] = "no";
					}
				// 				
				}
				else
				{
					echo "WHY?";
					$data['is_seller_top'] = "no";
				}*/
				if ($xpathdata->query("//div[@id='topratedplusimage']/@id"))
				{
					$value = $xpathdata->query("//div[@id='topratedplusimage']/@id");
					if ($value->item(0)->nodeValue)
					{
						$explodeval = $value->item(0)->nodeValue;
						if ($explodeval) $data['is_seller_top'] = "yes";
						else $data['is_seller_top'] = "no";
					}
					else
					{
						$value = $xpathdata->query("//span[@id='topratedplusimage']/@id");
						if ($value)
						{
							if ($value->item(0)->nodeValue)
							{
								$explodeval = $value->item(0)->nodeValue;
								if ($explodeval) $data['is_seller_top'] = "yes";
								else $data['is_seller_top'] = "no";
							}
							else
							{
								$data['is_seller_top'] = "no";
							}
						}
					}
				}
//die();
				if ($xpathdata->query("//img[@id='icImg']/@src"))
				{
					$value = $xpathdata->query("//img[@id='icImg']/@src");
					if ($value) $data['pro_img'] = trim($value->item(0)->nodeValue);
				}

				if ($xpathdata->query("//a[@id='sc_email']/@data-itemid"))
				{
					$value = $xpathdata->query("//a[@id='sc_email']/@data-itemid");
					if ($value) $data['item_id'] = trim($value->item(0)->nodeValue);
				}

				if ($xpathdata->query("//td[contains(text(),'EAN:')]/following-sibling::td"))
				{
					$value = $xpathdata->query("//td[contains(text(),'EAN:')]/following-sibling::td");
					if ($value) $data['ean'] = trim($value->item(0)->nodeValue);
				}

				if ($xpathdata->query("//td[contains(text(),'MPN:')]/following-sibling::td"))
				{
					$value = $xpathdata->query("//td[contains(text(),'MPN:')]/following-sibling::td");
					if ($value) $data['mpn'] = trim($value->item(0)->nodeValue);
				}

				if ($xpathdata->query("//td[contains(text(),'UPC:')]/following-sibling::td"))
				{
					$value = $xpathdata->query("//td[contains(text(),'UPC:')]/following-sibling::td");
					if ($value) $data['upc'] = trim($value->item(0)->nodeValue);
				}

				if ($xpathdata->query("//td[contains(text(),'ISBN:')]/following-sibling::td"))
				{
					$value = $xpathdata->query("//td[contains(text(),'ISBN:')]/following-sibling::td");
					if ($value) $data['isbn'] = trim($value->item(0)->nodeValue);
				}
			}

			$data['sold_date'] = $sold;
			$this->load->model("ebay_model");
			$count = $this->ebay_model->get_count($ebay_rec["schedule_id"]);
			if ($count >= 200)
			{
				$this->load->model("screen_message_model");

				//	$state = $this->setting_model->stop_script();
				//	die();

			}

			$expstr = "";
			$expstr = explode('/', $url);
			$data['item_id'] = trim($expstr[5]);
			if ($data['title'] != "")
			{
				$rec['url'] = $url;
				$rec['pro_title'] = $data['title'];
				$rec['pro_img'] = $data['pro_img'];
				$rec['pro_price'] = $this->remove_sym($data['price']);
				$rec['item_id'] = $data['item_id'];
				$rec['ean'] = $this->remove_sym($data['ean']);
				$rec['mpn'] = $this->remove_sym($data['mpn']);
				$rec['upc'] = $this->remove_sym($data['upc']);
				$rec['isbn'] = $this->remove_sym($data['isbn']);
				$rec['sold_count'] = $this->remove_sym($data['sold_count']);
				$rec['watchers'] = $this->remove_sym($data['watchers']);
				$rec['is_seller_top'] = $data['is_seller_top'];
				$rec['saller'] = $data['seller'];
				$rec['sold_date'] = $data['sold_date'];
				$rec['schedule_id'] = $ebay_rec["schedule_id"];
				$this->load->model("ebay_model");
				$ebay_url = $this->ebay_model->check_url($url, $ebay_rec["schedule_id"]);
				if (empty($ebay_url))
				{
					$this->ebay_model->add_new_record($rec);
				}
				else
				{
					$this->ebay_model->update_record($rec, $ebay_url["id"]);
				}
			}
			else
			{
				if ($url != "")
				{
					$rec['url'] = $url;

					// $this->load->model("ebay_model");
					// $this->ebay_model->add_new_record($rec);

				}
			}

			// $this->ebay_link_model->delete_url($ebay_rec["id"]);

			echo "done";
		}
	}

	
}
?>
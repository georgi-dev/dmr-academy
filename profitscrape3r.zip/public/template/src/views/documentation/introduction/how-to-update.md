# Why should I update?

Volta updates provide several performance improvements and useful new features which you can take advantage of. You can always see the latest changes in the ```CHANGELOG.md``` file.

---

To update __Volta__, besides getting new HTML examples, you will usually need to replace the following folders in your website:

- assets/js/
- assets/css/
